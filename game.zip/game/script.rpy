# ==============================================================================
# 1. CONFIGURAÇÕES GERAIS E INICIALIZAÇÃO
# ==============================================================================
define config.name = "TCC APP: Simulador Médico"
# Definindo a imagem 'capa.jpg' como plano de fundo do Menu Principal (com redimensionamento automático)
define gui.main_menu_background = Transform("images/capa.jpg", xsize=1920, ysize=1080)
define config.window_icon = "images/icone_app.png"

default cadastro_realizado = False
default nome_jogador = "Plantonista"
default matricula_jogador = "0000"
default voz_jogador = None
default intro_plantao_vista = False

# Definindo a transição de Flash (Clarão branco para o desfibrilador)
define flash = Fade(0.1, 0.0, 0.5, color="#ffffff")

init python:
    renpy.music.register_channel("monitor", "sfx", loop=True)
    # Registrando canal de áudio dedicado para a voz rítmica do minijogo de VPP
    renpy.music.register_channel("vpp_voice", "sfx", loop=True)
    # Canal exclusivo para a faixa-guia das compressões torácicas no caso ACLS.
    renpy.music.register_channel("rcp_voice", "sfx", loop=True)
    # Canal dedicado para o áudio/metrônomo das compressões torácicas no caso ACLS
    import random
    import json
    import time

    # Função integrada para salvar os resultados do TCC no seu Firebase
    def salvar_no_banco(nome, matricula, pontos, caso, resultado):
        url = "https://tcc-app-8d9ba-default-rtdb.firebaseio.com/pontuacoes.json"
        dados = {
            "nome": nome,
            "matricula": matricula,
            "pontuacao_final": pontos,
            "caso": caso,
            "resultado": resultado
        }
        dados_json = json.dumps(dados).encode('utf-8')
        try:
            renpy.fetch(url, method="POST", data=dados_json)
        except Exception as e:
            print("Erro ao salvar no banco de dados:", e)

# ==============================================================================
# 2. ESTILOS E INTERFACE (GUI) - DESIGN MODERNO
# ==============================================================================
style window:
    background Frame(Solid("#0b1015f2"), 12, 12)
    xalign 0.5 yalign 0.94
    xsize 1420 ysize 230
    padding (34, 26)

style say_dialogue:
    color "#ffffff" font "DejaVuSans.ttf" size 29
    outlines [(2, "#000000", 0, 0)]
    xalign 0.5
    text_align 0.0
    line_spacing 4
    xmaximum 1320

style namebox:
    background None xalign 0.5 yalign 0.0 padding (15, 5)

style say_label:
    color "#00e5ff" bold True size 34 outlines [(2, "#000000", 0, 0)] xalign 0.5

# Estilo moderno translúcido com brilho neon para escolhas gerais de diálogo
style choice_vbox:
    xalign 0.5 yalign 0.42 spacing 16

style choice_button:
    background Frame(Solid("#111a24d9"), 6, 6)
    hover_background Frame(Solid("#00e5ff"), 6, 6)
    padding (30, 20) xsize 1500

style choice_button_text:
    color "#ffffff" size 27 xalign 0.5
    text_align 0.0
    line_spacing 4
    hover_color "#0b1015"

style window:
    variant "small"
    xsize 1780
    ysize 330
    padding (44, 34)

style say_dialogue:
    variant "small"
    size 35
    line_spacing 6
    xmaximum 1660

style say_label:
    variant "small"
    size 42

style choice_vbox:
    variant "small"
    spacing 22

style choice_button:
    variant "small"
    xsize 1780
    padding (34, 26)

style choice_button_text:
    variant "small"
    size 34
    line_spacing 6

# ==============================================================================
# 3. ANIMAÇÕES E ECRÃS (SCREENS) GERAIS
# ==============================================================================

image icon_heart_anim:
    Text("♥", color="#e74c3c", size=35)
    zoom 1.0
    easein 0.4 zoom 1.2
    easeout 0.4 zoom 1.0
    repeat

transform flash_text:
    alpha 1.0
    linear 0.5 alpha 0.3
    linear 0.5 alpha 1.0
    repeat

# --- NOVO DESIGN DA TELA DE LOGIN (Substitui a barra feia do renpy.input padrão) ---
screen input(prompt):
    style_prefix "input"
    zorder 150
    modal True

    $ mobile_ui = renpy.variant("small")
    $ login_w = 1180 if mobile_ui else 850
    $ login_h = 610 if mobile_ui else 480
    $ login_title_size = 34 if mobile_ui else 24
    $ login_text_size = 30 if mobile_ui else 20
    $ login_input_size = 34 if mobile_ui else 24
    $ login_hint_size = 24 if mobile_ui else 16
    $ login_field_w = 920 if mobile_ui else 700
    $ login_field_h = 92 if mobile_ui else 70

    # Fundo de capa com desfoque/overlay escuro para destacar o painel de input
    add "bg capa"
    add Solid("#080c10dd")

    frame:
        align (0.5, 0.5)
        xsize login_w
        ysize login_h
        background Frame(Solid("#111a24f2"), 12, 12)
        padding (50, 45)

        vbox:
            spacing 25
            align (0.5, 0.5)
            xfill True

            # Ícone Decorativo Clínico
            text "👤" size 60 xalign 0.5

            # Cabeçalho Clínico
            text "SISTEMA DE IDENTIFICAÇÃO MÉDICA" size login_title_size bold True color "#00e5ff" xalign 0.5

            # Pergunta/Prompt dinâmico
            text prompt size login_text_size color "#ffffff" xalign 0.5 text_align 0.5

            # Campo de Digitação Customizado (estilo input de formulário moderno)
            frame:
                xalign 0.5
                xsize login_field_w
                ysize login_field_h
                background Frame(Solid("#1c2732"), 6, 6)
                padding (20, 15)

                # CORRIGIDO: Removido 'caret_color "#00e5ff"' que causava o erro de compilação
                input id "input" size login_input_size color "#ffffff" xalign 0.5 yalign 0.5

            # CORRIGIDO: Substituídos os colchetes [...] por chaves {...} na tag de cor para evitar o SyntaxError
            text "Pressione {color=#00e5ff}ENTER{/color} no teclado para confirmar" size login_hint_size color "#7f8c8d" xalign 0.5

# --- AVISO EDUCACIONAL EXIBIDO ANTES DO LOGIN ---
screen aviso_educacional():
    tag menu
    zorder 140
    modal True

    $ mobile_ui = renpy.variant("small")
    $ aviso_w = 1360 if mobile_ui else 980
    $ aviso_titulo_size = 46 if mobile_ui else 34
    $ aviso_texto_size = 32 if mobile_ui else 23
    $ aviso_tag_size = 23 if mobile_ui else 16
    $ aviso_botao_size = 31 if mobile_ui else 23

    add "bg capa"
    add Solid("#05080de6")

    frame:
        align (0.5, 0.5)
        xsize aviso_w
        background Frame(Solid("#101924f2"), 12, 12)
        padding (52, 46)

        vbox:
            spacing 22
            xfill True

            text "SIMULAÇÃO EDUCACIONAL" size aviso_titulo_size bold True color "#00e5ff" xalign 0.5
            text "Este aplicativo foi desenvolvido para treinamento acadêmico de tomada de decisão em emergências médicas. Os casos são inspirados em protocolos como SBP, ACLS e ATLS, mas não substituem treinamento supervisionado, protocolos institucionais ou atendimento médico real." size aviso_texto_size color "#e8f1f8" text_align 0.5 xalign 0.5 line_spacing 6

            null height 10

            hbox:
                xalign 0.5
                spacing 14
                frame:
                    background Solid("#16a085")
                    padding (14, 8)
                    text "SBP" size aviso_tag_size bold True color "#ffffff"
                frame:
                    background Solid("#c0392b")
                    padding (14, 8)
                    text "ACLS" size aviso_tag_size bold True color "#ffffff"
                frame:
                    background Solid("#34495e")
                    padding (14, 8)
                    text "ATLS" size aviso_tag_size bold True color "#ffffff"

            null height 8

            button:
                xalign 0.5
                xsize 520
                ysize 76
                background Frame(Solid("#00e5ff"), 8, 8)
                hover_background Frame(Solid("#2ecc71"), 8, 8)
                action Return(True)
                text "ENTENDI E QUERO CONTINUAR" align (0.5, 0.5) color "#071016" size aviso_botao_size bold True

# --- NOVA TELA MODERNA E ATRATIVA DE SELEÇÃO DE CASOS ---
screen tela_selecao_casos():
    tag menu
    add "bg capa"

    # Overlay escurecido para dar profundidade e destacar os cards
    add Solid("#080c10cc")

    # Cabeçalho da Tela
    vbox:
        xalign 0.5
        ypos 60
        spacing 10
        text "CENTRAL DE SIMULAÇÃO CLÍNICA" size 46 bold True color "#00e5ff" xalign 0.5 outlines [(2, "#000", 0, 0)]
        text "Escolha um protocolo e conduza o atendimento sob pressão, com feedback formativo ao final de cada decisão crítica" size 20 color "#a4b0be" xalign 0.5

    # Grid de casos lado a lado
    hbox:
        align (0.5, 0.6)
        spacing 36

        # --- CARD CASO 1: NEONATAL ---
        button:
            xsize 500
            ysize 610
            background Frame(Solid("#111a24e6"), 10, 10)
            hover_background Frame(Solid("#16a085ee"), 10, 10) # Brilho Neon Verde
            action Return("caso_neo")
            padding (34, 34)

            vbox:
                spacing 15
                xfill True

                # Tag de Especialidade
                frame:
                    background Solid("#16a085")
                    padding (12, 6)
                    xalign 0.0
                    text "PEDIATRIA" size 14 bold True color "#fff"

                # Título do Caso
                text "REANIMAÇÃO NEONATAL" size 28 bold True color "#ffffff"
                text "Diretrizes SBP 2022 / <34s" size 18 italic True color "#bdc3c7"

                null height 8

                # Sinopse Clínica
                text "Parto de alto risco, prematuro de 31 semanas em apneia e bradicardia. Estabilize termicamente, execute VPP no ritmo correto, avance para via aérea, compressões e adrenalina via cateter umbilical." size 18 color "#e2e8f0" line_spacing 3

                null height 12

                # Rodapé do Card
                text "Complexidade: Alta" size 16 bold True color "#f1c40f"
                text "Foco: Minuto de Ouro, termorregulação e VPP" size 15 color "#9fb3c5"

        # --- CARD CASO 2: CARDIOLOGIA ---
        button:
            xsize 500
            ysize 610
            background Frame(Solid("#111a24e6"), 10, 10)
            hover_background Frame(Solid("#c0392bee"), 10, 10) # Brilho Neon Vermelho
            action Return("caso_acls")
            padding (34, 34)

            vbox:
                spacing 15
                xfill True

                # Tag de Especialidade
                frame:
                    background Solid("#c0392b")
                    padding (12, 6)
                    xalign 0.0
                    text "CARDIOLOGIA" size 14 bold True color "#fff"

                # Título do Caso
                text "O BATISMO DE FOGO" size 28 bold True color "#ffffff"
                text "Diretrizes AHA/ACC 2025 - SCA e ACLS" size 18 italic True color "#bdc3c7"

                null height 8

                # Sinopse Clínica
                text "Atenda dor torácica típica, reconheça SCA e responda à parada em FV. Faça choque precoce, RCP de qualidade, drogas nos ciclos corretos e suporte pós-RCE." size 18 color "#e2e8f0" line_spacing 3

                null height 12

                # Rodapé do Card
                text "Complexidade: Crítica" size 16 bold True color "#e74c3c"
                text "Foco: CAB, desfibrilação e cuidados pós-parada" size 15 color "#9fb3c5"

        # --- CARD CASO 3: TRAUMA / ATLS ---
        button:
            xsize 500
            ysize 610
            background Frame(Solid("#111a24cc"), 10, 10)
            hover_background Frame(Solid("#34495eee"), 10, 10)
            action Return("caso_atls")
            padding (34, 34)

            vbox:
                spacing 15
                xfill True

                frame:
                    background Solid("#34495e")
                    padding (12, 6)
                    xalign 0.0
                    text "TRAUMA" size 14 bold True color "#fff"

                text "POLITRAUMA ATLS" size 28 bold True color "#ffffff"
                text "Avaliação primária ABCDE" size 18 italic True color "#bdc3c7"

                null height 8

                text "Atenda uma vítima de colisão moto-carro com choque, rebaixamento e suspeita de hemorragia interna. Siga o ABCDE, controle ameaças imediatas e decida quando usar FAST, TC e cirurgia." size 18 color "#e2e8f0" line_spacing 3

                null height 12

                text "Complexidade: Alta" size 16 bold True color "#f1c40f"
                text "Base: ATLS e atendimento inicial ao trauma" size 15 color "#9fb3c5"

# --- HUD E CHECKLIST (CASO 1: REANIMAÇÃO NEONATAL SBP 2022) ---
screen neonatal_hud():
    zorder 100
    frame:
        xalign 0.5 yalign 0.018 xsize 1360 ysize 96
        background Frame(Solid("#071017e6"), 10, 10)
        padding (18, 12)
        hbox:
            xalign 0.5 yalign 0.5 spacing 14

            frame:
                xsize 270 ysize 70 background Frame(Solid("#101c27"), 6, 6) padding (14, 8)
                vbox:
                    spacing 2
                    text "TEMPERATURA" color "#8fa6b8" size 14 bold True
                    text "[temp_neo]ºC" color ("#2ecc71" if (temp_neo >= 36.5 and temp_neo <= 37.5) else "#e74c3c") size 28 bold True

            frame:
                xsize 300 ysize 70 background Frame(Solid("#101c27"), 6, 6) padding (14, 8)
                vbox:
                    spacing 2
                    text "SAT O2 PRÉ-DUCTAL" color "#8fa6b8" size 14 bold True
                    text "[sato2_neo]%%" color ("#3498db" if sato2_neo >= 70 else "#f1c40f") size 28 bold True

            frame:
                xsize 260 ysize 70 background Frame(Solid("#101c27"), 6, 6) padding (14, 8)
                hbox:
                    spacing 10 yalign 0.5
                    add "icon_heart_anim" yalign 0.5
                    vbox:
                        spacing 2
                        text "FREQUÊNCIA" color "#8fa6b8" size 14 bold True
                        text "[fc_neo] bpm" color ("#e74c3c" if fc_neo < 100 else "#2ecc71") size 28 bold True

            frame:
                xsize 300 ysize 70 background Frame(Solid("#101c27"), 6, 6) padding (14, 8)
                vbox:
                    spacing 2
                    text "RITMO" color "#8fa6b8" size 14 bold True
                    text "[ritmo_neo]" color "#e67e22" size 28 bold True

screen botao_checklist_neonatal():
    zorder 105
    button:
        xalign 0.98 yalign 0.025 xsize 280 ysize 65
        background Frame(Solid("#e67e22"), 6, 6) hover_background Frame(Solid("#d35400"), 6, 6)
        action ToggleScreen("tela_prancheta_neonatal")
        hbox:
            align (0.5, 0.5) spacing 12
            text "📋" size 26 yalign 0.5
            text "SBP 2022 / <34s" size 20 bold True yalign 0.5 color "#fff"

screen tela_prancheta_neonatal():
    zorder 106
    modal True
    add Solid("#000000aa")
    frame:
        xalign 0.5 yalign 0.5 xsize 750 ysize 850
        background Frame(Solid("#fdfefe"), 10, 10)
        vbox:
            align (0.5, 0.1) spacing 15
            text "{color=#000}REANIMAÇÃO NEONATAL <34s{/color}" size 32 bold True xalign 0.5
            null height 15
            $ items = [
                ("1. Preparação da Sala (23-25ºC) e Material", check_preparacao),
                ("2. Estabilização Térmica (Sem Secar RN)", check_passos_iniciais),
                ("3. VPP Rítmica 'Aperta, Solta, Solta' com 30%% O2", check_vpp),
                ("4. Intubação orotraqueal com cânula 3.0", check_intubacao),
                ("5. Massagem Cardíaca Coordenada 3:1", check_massagem),
                ("6. Cateterismo Umbilical & Adrenalina", check_drogas_neo)
            ]
            for label_text, state in items:
                hbox:
                    spacing 20
                    if state:
                        text "✅" size 24
                        text label_text color "#27ae60" size 24 strikethrough True
                    else:
                        text "🔲" size 24
                        text label_text color "#7f8c8d" size 24
        textbutton "FECHAR":
            align (0.5, 0.95) action ToggleScreen("tela_prancheta_neonatal") text_color "#c0392b" text_size 30 text_bold True

# --- HUD E CHECKLIST (CASO 2: ACLS / CARDIOLOGIA) ---
screen acls_hud():
    zorder 100
    frame:
        xalign 0.12 yalign 0.018 xsize 1390 ysize 96
        background Frame(Solid("#071017e6"), 10, 10)
        padding (16, 12)
        hbox:
            xalign 0.5 yalign 0.5 spacing 12

            # Saúde do Coração (Vida)
            frame:
                xsize 240 ysize 70 background Frame(Solid("#101c27"), 6, 6) padding (14, 8)
                vbox:
                    spacing 2
                    text "MÚSCULO CARDÍACO" color "#8fa6b8" size 14 bold True
                    if vida_coracao <= 30:
                        text "CRÍTICO" color "#e74c3c" bold True size 26 at flash_text
                    else:
                        text "[vida_coracao]%" color "#2ecc71" size 28 bold True

            # Estado do Ritmo
            frame:
                xsize 280 ysize 70 background Frame(Solid("#101c27"), 6, 6) padding (14, 8)
                vbox:
                    spacing 2
                    text "RITMO" color "#8fa6b8" size 14 bold True
                    if ritmo == "sinusal":
                        text "SINUSAL" color "#3498db" size 26 bold True
                    elif ritmo == "fv":
                        text "FV / CHOCÁVEL" color "#e74c3c" bold True size 22 at flash_text
                    elif ritmo == "assistolia":
                        text "ASSISTOLIA" color "#c0392b" bold True size 26

            frame:
                xsize 225 ysize 70 background Frame(Solid("#101c27"), 6, 6) padding (14, 8)
                hbox:
                    spacing 8 yalign 0.5
                    add "icon_heart_anim" yalign 0.5
                    vbox:
                        spacing 2
                        text "FC" color "#8fa6b8" size 14 bold True
                        if ritmo == "sinusal":
                            text "[fc_acls] bpm" color ("#f1c40f" if fc_acls > 120 else "#2ecc71") size 25 bold True
                        elif ritmo == "fv":
                            text "SEM PULSO" color "#e74c3c" size 20 bold True at flash_text
                        elif ritmo == "assistolia":
                            text "0 bpm" color "#c0392b" size 25 bold True

            frame:
                xsize 270 ysize 70 background Frame(Solid("#101c27"), 6, 6) padding (14, 8)
                vbox:
                    spacing 2
                    text "PRESSÃO ARTERIAL" color "#8fa6b8" size 13 bold True
                    if ritmo == "sinusal":
                        text "[pas_acls]/[pad_acls] mmHg" color ("#e74c3c" if pas_acls < 90 else "#f1c40f" if pas_acls >= 140 else "#2ecc71") size 24 bold True
                    elif ritmo == "fv":
                        text "NÃO AFERÍVEL" color "#e74c3c" size 19 bold True at flash_text
                    elif ritmo == "assistolia":
                        text "SEM PULSO" color "#c0392b" size 22 bold True

            frame:
                xsize 235 ysize 70 background Frame(Solid("#101c27"), 6, 6) padding (14, 8)
                vbox:
                    spacing 2
                    text "PRIORIDADE" color "#8fa6b8" size 14 bold True
                    if ritmo == "fv":
                        text "CHOQUE + RCP" color "#e74c3c" size 21 bold True
                    elif ritmo == "assistolia":
                        text "RCP + DROGAS" color "#c0392b" size 21 bold True
                    else:
                        text "MONITORAR" color "#2ecc71" size 22 bold True

screen botao_checklist_acls():
    zorder 105
    button:
        xalign 0.98 yalign 0.025 xsize 280 ysize 65
        background Frame(Solid("#e74c3c"), 6, 6) hover_background Frame(Solid("#c0392b"), 6, 6)
        action ToggleScreen("tela_prancheta_acls")
        hbox:
            align (0.5, 0.5) spacing 12
            text "📋" size 26 yalign 0.5
            text "ACLS / C-A-B" size 20 bold True yalign 0.5 color "#fff"

screen tela_prancheta_acls():
    zorder 106
    modal True
    add Solid("#000000aa")
    frame:
        xalign 0.5 yalign 0.5 xsize 750 ysize 850
        background Frame(Solid("#fdfefe"), 10, 10)
        vbox:
            align (0.5, 0.1) spacing 15
            text "{color=#000}DIRETRIZES AHA/ACC 2025 - SCA E ACLS{/color}" size 32 bold True xalign 0.5
            null height 15
            $ items = [
                ("SCA: ECG em < 10 min e AAS", check_ecg),
                ("Código Azul e Pulso/Resp (< 10s)", check_pulso),
                ("Desfibrilação Precoce (FV/TV)", check_choque),
                ("Vasopressores e Antiarrítmicos na PCR", check_drogas_pcr),
                ("Suporte Vasoativo Pós-RCE", check_vasoativo)
            ]
            for label_text, state in items:
                hbox:
                    spacing 20
                    if state:
                        text "✅" size 24
                        text label_text color "#27ae60" size 24 strikethrough True
                    else:
                        text "🔲" size 24
                        text label_text color "#7f8c8d" size 24
        textbutton "FECHAR":
            align (0.5, 0.95) action ToggleScreen("tela_prancheta_acls") text_color "#c0392b" text_size 30 text_bold True

# --- HUD E CHECKLIST (CASO 3: POLITRAUMA / ATLS) ---
screen trauma_hud():
    zorder 100
    frame:
        xalign 0.43 yalign 0.018 xsize 1280 ysize 118
        background Frame(Solid("#071017ee"), 10, 10)
        padding (16, 10)
        vbox:
            spacing 8
            xfill True

            hbox:
                xfill True
                text "MONITOR DE TRAUMA" color "#00e5ff" size 14 bold True
                text "  |  AVALIAÇÃO PRIMÁRIA ATLS" color "#8fa6b8" size 14 bold True

            hbox:
                xalign 0.5 yalign 0.5 spacing 10

                frame:
                    xsize 180 ysize 68 background Frame(Solid("#101c27"), 6, 6) padding (12, 8)
                    vbox:
                        spacing 1
                        text "PA" color "#8fa6b8" size 13 bold True
                        text "[pa_trauma]" color ("#e74c3c" if pa_sistolica_trauma < 90 else "#2ecc71") size 25 bold True

                frame:
                    xsize 165 ysize 68 background Frame(Solid("#101c27"), 6, 6) padding (12, 8)
                    vbox:
                        spacing 1
                        text "SatO2" color "#8fa6b8" size 13 bold True
                        text "[sato2_trauma]%%" color ("#e74c3c" if sato2_trauma < 92 else "#3498db") size 25 bold True

                frame:
                    xsize 185 ysize 68 background Frame(Solid("#101c27"), 6, 6) padding (12, 8)
                    vbox:
                        spacing 1
                        text "FC" color "#8fa6b8" size 13 bold True
                        text "[fc_trauma] bpm" color ("#e74c3c" if fc_trauma > 120 else "#2ecc71") size 25 bold True

                frame:
                    xsize 145 ysize 68 background Frame(Solid("#101c27"), 6, 6) padding (12, 8)
                    vbox:
                        spacing 1
                        text "GLASGOW" color "#8fa6b8" size 13 bold True
                        text "[glasgow_trauma]" color ("#f1c40f" if glasgow_trauma <= 13 else "#2ecc71") size 25 bold True

                frame:
                    xsize 175 ysize 68 background Frame(Solid("#101c27"), 6, 6) padding (12, 8)
                    vbox:
                        spacing 1
                        text "TEMP" color "#8fa6b8" size 13 bold True
                        text "[temp_trauma]ºC" color ("#e74c3c" if temp_trauma < 36 else "#2ecc71") size 25 bold True

                frame:
                    xsize 330 ysize 68 background Frame(Solid("#1d2d3b"), 6, 6) padding (12, 8)
                    vbox:
                        spacing 1
                        text "PRIORIDADE" color "#8fa6b8" size 13 bold True
                        text "[prioridade_trauma]" color "#f1c40f" size 24 bold True

screen botao_checklist_trauma():
    zorder 105
    button:
        xalign 0.985 ypos 138 xsize 250 ysize 62
        background Frame(Solid("#34495e"), 6, 6) hover_background Frame(Solid("#2c3e50"), 6, 6)
        action ToggleScreen("tela_prancheta_trauma")
        hbox:
            align (0.5, 0.5) spacing 12
            text "📋" size 26 yalign 0.5
            text "ATLS / ABCDE" size 20 bold True yalign 0.5 color "#fff"

screen tela_prancheta_trauma():
    zorder 106
    modal True
    add Solid("#000000aa")
    frame:
        xalign 0.5 yalign 0.5 xsize 800 ysize 850
        background Frame(Solid("#fdfefe"), 10, 10)
        vbox:
            align (0.5, 0.1) spacing 15
            text "{color=#000}ATLS - AVALIAÇÃO PRIMÁRIA ABCDE{/color}" size 30 bold True xalign 0.5
            null height 15
            $ items = [
                ("A. Via aérea com proteção cervical", check_trauma_a),
                ("B. Respiração: tórax, oxigênio e descompressão", check_trauma_b),
                ("C. Circulação: hemorragia, acessos e hemoderivados", check_trauma_c),
                ("D. Neurológico: Glasgow, pupilas e glicemia", check_trauma_d),
                ("E. Exposição completa e prevenção de hipotermia", check_trauma_e),
                ("Adjuntos: FAST e cirurgia/controle de dano", check_trauma_adj)
            ]
            for label_text, state in items:
                hbox:
                    spacing 20
                    if state:
                        text "✅" size 24
                        text label_text color "#27ae60" size 23 strikethrough True
                    else:
                        text "🔲" size 24
                        text label_text color "#7f8c8d" size 23
        textbutton "FECHAR":
            align (0.5, 0.95) action ToggleScreen("tela_prancheta_trauma") text_color "#34495e" text_size 30 text_bold True

screen menu_atls(titulo, opcoes):
    zorder 99
    modal True

    $ mobile_ui = renpy.variant("small")
    $ menu_w = 1680 if mobile_ui else 1120
    $ menu_y = 150 if mobile_ui else 185
    $ titulo_menu_size = 34 if mobile_ui else 25
    $ opcao_size = 31 if mobile_ui else 22
    $ opcao_min_h = 112 if mobile_ui else 78
    $ menu_pad_x = 34 if mobile_ui else 26
    $ menu_pad_y = 30 if mobile_ui else 24
    $ opcao_pad_x = 30 if mobile_ui else 24
    $ opcao_pad_y = 24 if mobile_ui else 18
    $ opcao_line_spacing = 6 if mobile_ui else 4

    frame:
        xalign 0.5
        ypos menu_y
        xsize menu_w
        background Frame(Solid("#071017dc"), 10, 10)
        padding (menu_pad_x, menu_pad_y)

        vbox:
            spacing 18
            xfill True

            text titulo size titulo_menu_size bold True color "#00e5ff" xalign 0.5 text_align 0.5

            for legenda, retorno in opcoes:
                button:
                    xfill True
                    yminimum opcao_min_h
                    background Frame(Solid("#132231e8"), 7, 7)
                    hover_background Frame(Solid("#34495e"), 7, 7)
                    padding (opcao_pad_x, opcao_pad_y)
                    action Return(retorno)
                    text legenda size opcao_size color "#ffffff" hover_color "#ffffff" xalign 0.5 text_align 0.5 line_spacing opcao_line_spacing

screen debriefing_simples(titulo, resultado, desfecho, pontos_finais, protocolo, acertos, atencao):
    zorder 200
    modal True
    add Solid("#05080bee")

    $ mobile_ui = renpy.variant("small")
    $ painel_w = 1660 if mobile_ui else 1320
    $ painel_h = 900 if mobile_ui else 780
    $ titulo_size = 52 if mobile_ui else 46
    $ subtitulo_size = 32 if mobile_ui else 29
    $ texto_size = 30 if mobile_ui else 26
    $ pequeno_size = 26 if mobile_ui else 23
    $ pontos_h = 250 if mobile_ui else 220
    $ debrief_h = 170 if mobile_ui else 150
    $ botao_texto_size = 36 if mobile_ui else 30
    $ cabecalho_text_w = painel_w - 590
    $ item_text_w = painel_w - 190
    $ atencao_text_w = painel_w - 120
    $ botao_w = 520 if mobile_ui else 420
    $ cor_resultado = "#2ecc71" if resultado == "Sucesso" else "#e74c3c"

    frame:
        align (0.5, 0.5)
        xsize painel_w
        ysize painel_h
        background Frame(Solid("#101923f8"), 10, 10)
        padding (48, 42)

        vbox:
            spacing 22
            xfill True

            hbox:
                xfill True
                spacing 20

                frame:
                    xsize 84
                    ysize 84
                    background Frame(Solid(cor_resultado), 8, 8)
                    text ("✓" if resultado == "Sucesso" else "!") align (0.5, 0.5) size 48 color "#071016" bold True

                vbox:
                    yalign 0.5
                    xsize cabecalho_text_w
                    spacing 6
                    text titulo size titulo_size bold True color cor_resultado xmaximum cabecalho_text_w
                    text protocolo size pequeno_size color "#00e5ff" xmaximum cabecalho_text_w
                    text "DESFECHO: [desfecho]" size pequeno_size color cor_resultado bold True xmaximum cabecalho_text_w

                frame:
                    xalign 1.0
                    xsize 330
                    ysize 84
                    background Frame(Solid("#0b1219"), 8, 8)
                    vbox:
                        align (0.5, 0.5)
                        spacing 2
                        text resultado.upper() size 19 color cor_resultado bold True xalign 0.5
                        text "[pontos_finais] pontos" size subtitulo_size color "#ffffff" bold True xalign 0.5

            frame:
                xfill True
                yminimum pontos_h
                background Frame(Solid("#0b1219"), 7, 7)
                padding (30, 24)
                vbox:
                    spacing 14
                    text "Pontos principais" size subtitulo_size bold True color "#ffffff"
                    for item in acertos:
                        hbox:
                            spacing 14
                            text "•" size texto_size color cor_resultado bold True
                            text item size texto_size color "#dfeaf2" line_spacing 5 xmaximum item_text_w

            frame:
                xfill True
                yminimum debrief_h
                background Frame(Solid("#1d2d3b"), 7, 7)
                padding (30, 24)
                vbox:
                    spacing 10
                    text "Debriefing curto" size subtitulo_size bold True color "#f1c40f"
                    text atencao size texto_size color "#ffffff" line_spacing 6 xmaximum atencao_text_w

            frame:
                xfill True
                ysize 92
                background None

                textbutton "CONTINUAR":
                    align (0.5, 0.5)
                    xsize botao_w
                    ysize 78
                    background Frame(Solid("#00e5ff"), 7, 7)
                    hover_background Frame(Solid("#2ecc71"), 7, 7)
                    text_color "#071016"
                    text_hover_color "#071016"
                    text_size botao_texto_size
                    text_bold True
                    text_xalign 0.5
                    action Return()

screen menu_pos_falha(titulo, subtitulo):
    zorder 210
    modal True
    add Solid("#05080bf2")

    $ mobile_ui = renpy.variant("small")
    $ painel_w = 1300 if not mobile_ui else 1660
    $ painel_h = 560 if not mobile_ui else 720
    $ titulo_size = 44 if not mobile_ui else 56
    $ texto_size = 25 if not mobile_ui else 33
    $ botao_size = 27 if not mobile_ui else 36
    $ botao_h = 82 if not mobile_ui else 104
    $ botao_w = painel_w - 180
    $ subtitulo_w = painel_w - 220

    frame:
        align (0.5, 0.5)
        xsize painel_w
        ysize painel_h
        background Frame(Solid("#101923f8"), 10, 10)
        padding (48, 42)

        vbox:
            spacing 24
            xfill True

            hbox:
                spacing 22
                xalign 0.5
                frame:
                    xsize 82
                    ysize 82
                    background Frame(Solid("#e74c3c"), 8, 8)
                    text "!" align (0.5, 0.5) size 52 color "#071016" bold True
                vbox:
                    yalign 0.5
                    spacing 6
                    text titulo size titulo_size color "#e74c3c" bold True
                    text subtitulo size texto_size color "#dfeaf2" line_spacing 5 xmaximum subtitulo_w

            null height 8

            vbox:
                spacing 16
                xalign 0.5

                button:
                    xsize botao_w
                    ysize botao_h
                    background Frame(Solid("#00e5ff"), 7, 7)
                    hover_background Frame(Solid("#2ecc71"), 7, 7)
                    action Return("retry")
                    text "TENTAR NOVAMENTE" align (0.5, 0.5) size botao_size color "#071016" bold True

                button:
                    xsize botao_w
                    ysize botao_h
                    background Frame(Solid("#1d2d3b"), 7, 7)
                    hover_background Frame(Solid("#34495e"), 7, 7)
                    action Return("casos")
                    text "VOLTAR À SELEÇÃO DE CASOS" align (0.5, 0.5) size botao_size color "#ffffff" bold True

                button:
                    xsize botao_w
                    ysize botao_h
                    background Frame(Solid("#2b1418"), 7, 7)
                    hover_background Frame(Solid("#c0392b"), 7, 7)
                    action Return("sair")
                    text "SAIR DO JOGO" align (0.5, 0.5) size botao_size color "#ffffff" bold True

# --- MENU CRONOMETRADO (EXCLUSIVO CASO 2 - CENA 4) ---
screen menu_cronometrado_acls():
    zorder 110
    modal True

    default tempo_restante = 10.0 # 10 Segundos para agir!

    timer 0.1 repeat True action SetScreenVariable("tempo_restante", tempo_restante - 0.1)

    if tempo_restante <= 0:
        timer 0.01 action Return("timeout")

    # Fundo que pisca vermelho alertando o perigo
    add Solid("#e74c3c33") at flash_text

    vbox:
        xalign 0.5 yalign 0.1
        text "RITMO CHOCÁVEL: AJA AGORA" size 50 color "#e74c3c" bold True outlines [(3, "#000", 0, 0)]
        text "TEMPO PARA DEFINIR A CONDUTA: [tempo_restante:.1f] SEGUNDOS" size 37 color "#f1c40f" bold True outlines [(2, "#000", 0, 0)] xalign 0.5

    vbox:
        xalign 0.5 yalign 0.6 spacing 25

        button:
            xsize 1200 ysize 100 background Frame(Solid("#1c2833e6"), 4, 4) hover_background Frame(Solid("#c0392b"), 4, 4)
            action Return("choque")
            text "A) FV sem pulso: aplicar choque bifásico de 200 J e retomar RCP imediatamente por 2 minutos." align (0.5, 0.5) color "#fff" size 24 bold True

        button:
            xsize 1200 ysize 100 background Frame(Solid("#1c2833e6"), 4, 4) hover_background Frame(Solid("#c0392b"), 4, 4)
            action Return("adrenalina")
            text "B) Administrar adrenalina 1 mg IV antes do primeiro choque." align (0.5, 0.5) color "#fff" size 24 bold True

        button:
            xsize 1200 ysize 100 background Frame(Solid("#1c2833e6"), 4, 4) hover_background Frame(Solid("#c0392b"), 4, 4)
            action Return("intubar")
            text "C) Priorizar intubação antes de desfibrilar o ritmo chocável." align (0.5, 0.5) color "#fff" size 24 bold True


# --- MINIJOGOS (CASO 1: REANIMAÇÃO NEONATAL) ---

# --- MINIJOGO DE VENTILAÇÃO RÍTMICA COMPACTO 'APERTA, SOLTA, SOLTA' SINCRONIZADO COM ÁUDIO ---
screen minigame_vpp_neonatal():
    zorder 110
    modal True

    # Inicia a reprodução do áudio gravado em loop perfeitamente sincronizado com o surgimento do ecrã no canal dedicado
    on "show" action Play("vpp_voice", "audio/aperta_solta_solta.mp3", loop=True)
    # Garante a interrupção ao sair do minijogo
    on "hide" action Stop("vpp_voice")

    default tempo_ciclo = 0.0
    default last_tempo_ciclo = 0.0
    default vent_certas = 0
    default erros = 0
    default ja_ventilou_neste_ciclo = False
    default erro_registrado_neste_ciclo = False

    # Timer de alta precisão (intervalos de 0.05 segundos) recalibrado com sincronia de áudio absoluta
    # Agora exige 40 ventilações certas (equivalente a 1 min de VPP real SBP) e permite até 8 erros
    if vent_certas < 40 and erros < 8:
        timer 0.05 repeat True action [
            # 1. Salva o valor anterior para detectar quando o áudio reiniciar
            SetScreenVariable("last_tempo_ciclo", tempo_ciclo),

            # 2. Sincroniza o tempo_ciclo diretamente com a posição real da faixa de áudio no canal vpp_voice (evita o drift natural)
            SetScreenVariable("tempo_ciclo", renpy.music.get_pos("vpp_voice") % 1.5 if renpy.music.get_pos("vpp_voice") is not None else (tempo_ciclo + 0.05) % 1.5),

            # 3. Se a posição atual for menor que o ciclo anterior, significa que o áudio deu a volta (looping de 1.5s reiniciado)
            If(tempo_ciclo < last_tempo_ciclo, [
                SetScreenVariable("ja_ventilou_neste_ciclo", False),
                SetScreenVariable("erro_registrado_neste_ciclo", False)
            ]),

            # --- MONITORAMENTO DO RITMO CLINÍCO (Bip do Caso 1 removido por completo) ---
            # Se o tempo passou de 0.5s (fim do 'Aperta') e o aluno não ventilou, acusa erro automático por atrasar a ventilação do bebê
            If(tempo_ciclo >= 0.5 and not ja_ventilou_neste_ciclo and not erro_registrado_neste_ciclo, [
                # Removido feedback de bip sonoro para evitar sobreposição com o áudio rítmico principal do Caso 1
                SetScreenVariable("erros", erros + 1),
                SetScreenVariable("erro_registrado_neste_ciclo", True),
                If(erros + 1 >= 8, Return("fail"))
            ])
        ]

    add Solid("#0b1015f9") # Monitor clínico de UTI Neonatal

    frame:
        align (0.5, 0.5) xsize 1100 ysize 750
        background Frame(Solid("#16a08533"), 10, 10)
        padding (30, 30)

        vbox:
            spacing 25
            xfill True

            text "SUPORTE VENTILATÓRIO: APERTA, SOLTA, SOLTA" size 28 bold True color "#00e5ff" xalign 0.5
            text "Pressione o botão 'APERTA BALÃO' apenas quando a barra estiver no azul (fase de insuflação 'Aperta'). Respeite o tempo de expiração do neonato." size 20 color "#b2bec3" xalign 0.5 text_align 0.5

            null height 10

            # Painel com Sinais de Evolução Clínica do Neonato
            hbox:
                xalign 0.5
                spacing 80
                vbox:
                    spacing 5
                    text "VENTILAÇÕES CORRETAS" size 16 color "#b2bec3" xalign 0.5
                    text "[vent_certas] / 40" size 36 color "#2ecc71" bold True xalign 0.5

                # Visual do Pulmão que muda de coloração de azul cianótico para rosa saudável baseado em acertos (escala ajustada para meta de 40)
                vbox:
                    spacing 5
                    text "COLORAÇÃO CUTÂNEA" size 16 color "#b2bec3" xalign 0.5
                    frame:
                        xalign 0.5 xsize 140 ysize 60
                        if vent_certas == 0:
                            background Solid("#3498db") # Cianótico completo
                            text "CIANÓTICO" align (0.5, 0.5) color "#fff" size 14 bold True
                        elif vent_certas < 10:
                            background Solid("#5f27cd")
                            text "ASFIXIADO" align (0.5, 0.5) color "#fff" size 14 bold True
                        elif vent_certas < 20:
                            background Solid("#8c7ae6")
                            text "MISTO" align (0.5, 0.5) color "#fff" size 14 bold True
                        elif vent_certas < 30:
                            background Solid("#fd79a8")
                            text "PERFUNDINDO" align (0.5, 0.5) color "#fff" size 14 bold True
                        else:
                            background Solid("#ff7675") # Corrosada saudável
                            text "COR-DE-ROSA" align (0.5, 0.5) color "#fff" size 14 bold True

                vbox:
                    spacing 5
                    text "ERROS COMETIDOS" size 16 color "#b2bec3" xalign 0.5
                    text "[erros] / 8" size 36 color "#e74c3c" bold True xalign 0.5

            # Barra Sincronizada com Linha Temporal
            frame:
                xalign 0.5 xsize 900 ysize 120 background Solid("#2d3436")

                # ZONAS TEMPORAIS
                if tempo_ciclo < 0.5:
                    # Zona Correta de Insuflação (Aperta)
                    frame:
                        align (0.5, 0.5) xsize 880 ysize 100 background Solid("#2980b9")
                        text "● APERTA BALÃO (0.0s - 0.5s)" align (0.5, 0.5) size 26 color "#fff" bold True at flash_text
                else:
                    # Zona de Relaxamento Passivo (Solta... Solta...)
                    frame:
                        align (0.5, 0.5) xsize 880 ysize 100 background Solid("#2c3e50")
                        text "SOLTA... SOLTA... AGUARDE (0.5s - 1.5s)" align (0.5, 0.5) size 20 color "#7f8c8d" bold True

            # Barra dinâmica de progressão do tempo
            bar:
                xalign 0.5
                value tempo_ciclo
                range 1.5
                xsize 900
                ysize 15
                left_bar Solid("#00e5ff")
                right_bar Solid("#444")

            null height 15

            # Botão de Aperto do Balão que exige obediência de fase (Removido todos os bips sonoros)
            button:
                xalign 0.5 xsize 500 ysize 100
                background Frame(Solid("#2ecc71" if tempo_ciclo < 0.5 else "#e74c3c"), 6, 6)
                hover_background Frame(Solid("#27ae60" if tempo_ciclo < 0.5 else "#c0392b"), 6, 6)
                action [
                    If(tempo_ciclo < 0.5,
                       If(not ja_ventilou_neste_ciclo,
                          [
                              SetScreenVariable("vent_certas", vent_certas + 1),
                              SetScreenVariable("ja_ventilou_neste_ciclo", True),
                              If(vent_certas + 1 >= 40, Return("win"))
                          ],
                          # Pune se clicar duas vezes no mesmo ciclo
                          [
                              SetScreenVariable("erros", erros + 1),
                              If(erros + 1 >= 8, Return("fail"))
                          ]
                       ),
                       # Pune se clicar na fase errada (Solta, Solta)
                       [
                           SetScreenVariable("erros", erros + 1),
                           If(erros + 1 >= 8, Return("fail"))
                       ]
                    )
                ]
                text "APERTA BALÃO" align (0.5, 0.5) size 32 color "#fff" bold True

# --- MINIJOGO DE TEMPO E COMPRESSÃO/VENTILAÇÃO COORDENADA 3:1 (NEONATAL) ---
screen minigame_rcp_neonatal():
    zorder 110
    modal True

    default ciclos_completos = 0
    default passo = 0 # 0, 1, 2 = Compressão (Polegares); 3 = Ventilação (Ambu)
    default tempo_total = 15.0

    timer 0.1 repeat True action SetScreenVariable("tempo_total", tempo_total - 0.1)
    if tempo_total <= 0:
        timer 0.01 action Return("fail")

    add Solid("#0b1015f2")

    vbox:
        align (0.5, 0.15) spacing 15
        text "COORDENAÇÃO DA RCP NEONATAL (PROPORÇÃO 3:1)" size 36 bold True color "#e74c3c" xalign 0.5
        text "Execute o ritmo estrito da SBP: 'Um, Dois, Três, Ventila!'. Pressione as ações na ordem correta." size 20 color "#b2bec3" xalign 0.5
        hbox:
            xalign 0.5 spacing 60
            text "Ciclos Executados: [ciclos_completos] / 4" size 28 color "#2ecc71" bold True
            text "Tempo Restante: [tempo_total:.1f]s" size 28 color "#f1c40f" bold True

    # Instrução visual de ritmo
    vbox:
        align (0.5, 0.45) spacing 20
        if passo == 0:
            text "PRÓXIMO PASSO: {color=#e74c3c}COMPRESSÃO 1{/color}" size 35 bold True xalign 0.5 at flash_text
        elif passo == 1:
            text "PRÓXIMO PASSO: {color=#e74c3c}COMPRESSÃO 2{/color}" size 35 bold True xalign 0.5 at flash_text
        elif passo == 2:
            text "PRÓXIMO PASSO: {color=#e74c3c}COMPRESSÃO 3{/color}" size 35 bold True xalign 0.5 at flash_text
        elif passo == 3:
            text "PRÓXIMO PASSO: {color=#3498db}VENTILAÇÃO!{/color}" size 35 bold True xalign 0.5 at flash_text

    # Botões de Ação Dinâmicos
    hbox:
        align (0.5, 0.75) spacing 80

        # Botão de Compressão (Polegares)
        button:
            xsize 320 ysize 120
            background Frame(Solid("#e74c3c" if passo < 3 else "#333"), 6, 6)
            action [
                If(passo < 3,
                   SetScreenVariable("passo", passo + 1),
                   SetScreenVariable("tempo_total", tempo_total - 2.0) # Penalidade se apertar fora de hora
                )
            ]
            vbox:
                align (0.5, 0.5)
                text "👍👍" size 30 xalign 0.5
                text "COMPRIMIR" size 22 bold True xalign 0.5 color "#fff"

        # Botão de Ventilação (Ambu)
        button:
            xsize 320 ysize 120
            background Frame(Solid("#3498db" if passo == 3 else "#333"), 6, 6)
            action [
                If(passo == 3,
                   [
                       SetScreenVariable("passo", 0),
                       SetScreenVariable("ciclos_completos", ciclos_completos + 1),
                       If(ciclos_completos + 1 >= 4, Return("win"))
                   ],
                   SetScreenVariable("tempo_total", tempo_total - 2.0) # Penalidade
                )
            ]
            vbox:
                align (0.5, 0.5)
                text "💨" size 30 xalign 0.5
                text "VENTILAR" size 22 bold True xalign 0.5 color "#fff"

# --- MINIJOGO DE VISUALIZAÇÃO DA GLOTE E ENTUBAÇÃO (NEONATAL) ---
screen minigame_intubacao_neonatal():
    zorder 105
    modal True
    default local_selecionado = None
    add Solid("#0a0a0acc")

    frame:
        align (0.5, 0.5) xsize 1100 ysize 800 background Frame(Solid("#1c1c1c"), 4, 4)
        vbox:
            align (0.5, 0.05)
            text "LARINGOSCOPIA DIRETA: LOCALIZE A GLOTE" size 28 color "#3498db" xalign 0.5
            text "Selecione o local correto para posicionar a lâmina do laringoscópio para visualizar as cordas vocais." size 18 color "#aaa" xalign 0.5

        # Alvo correto: Valécula (atrás da epiglote)
        button:
            xpos 420 ypos 300 xsize 260 ysize 140 background Solid("#2ecc711a") hover_background Solid("#2ecc7180")
            action SetScreenVariable("local_selecionado", "sucesso")
            text "VALÉCULA (Atrás da Epiglote)" align (0.5, 0.5) color "#fff" bold True

        # Erro grave: Esôfago
        button:
            xpos 150 ypos 480 xsize 320 ysize 140 background Solid("#e74c3c1a") hover_background Solid("#e74c3c80")
            action SetScreenVariable("local_selecionado", "erro_esofago")
            text "ABERTURA DO ESÔFAGO" align (0.5, 0.5) color "#fff" bold True

        # Erro: Pregas vestibulares laterais
        button:
            xpos 630 ypos 480 xsize 320 ysize 140 background Solid("#e74c3c1a") hover_background Solid("#e74c3c80")
            action SetScreenVariable("local_selecionado", "erro_parede")
            text "PAREDE FARÍNGEA LATERAL" align (0.5, 0.5) color "#fff" bold True

    if local_selecionado:
        frame:
            align (0.5, 0.9) background Frame(Solid("#000000ee"), 10, 10) padding (30, 20)
            hbox:
                spacing 60 xalign 0.5
                textbutton "CONFIRMAR INSERÇÃO":
                    text_size 35 text_color "#2ecc71" text_bold True action Return(local_selecionado)
                textbutton "REAVALIAÇÃO":
                    text_size 35 text_color "#c0392b" action SetScreenVariable("local_selecionado", None)

# --- MINIJOGO DE POSICAO E COMPRESSOES TORACICAS RITMADAS (ACLS) ---
screen minigame_rcp():
    zorder 110
    modal True

    on "show" action Play("sound", "audio/minijogos/acls/instrucao_rcp_inicio.mp3")
    on "hide" action [Stop("rcp_voice"), Stop("sound")]

    default etapa_rcp = "posicao"
    default compressoes_certas = 0
    default erros = 0
    default erros_posicao = 0
    default tempo_restante = 60.0
    default alerta_posicao = False
    default feedback_rcp = "Toque no local em que posicionaria as maos para iniciar a RCP."

    # Meta didatica de 110/min; a faixa clinicamente adequada e 100-120/min.
    $ tempo_decorrido = 60.0 - tempo_restante
    $ ritmo_medio = int(round((compressoes_certas * 60.0) / tempo_decorrido)) if tempo_decorrido >= 3.0 else 0
    $ ciclo_guia_rcp = 60.0 / 110.0
    $ posicao_audio_rcp = renpy.music.get_pos("rcp_voice") if etapa_rcp == "ritmo" else None
    $ fase_guia_rcp = (posicao_audio_rcp % ciclo_guia_rcp) if posicao_audio_rcp is not None else ciclo_guia_rcp
    $ sinal_comprimir = etapa_rcp == "ritmo" and fase_guia_rcp < 0.18
    # Area clicavel centrada na metade inferior do esterno, apos o recorte visual da imagem.
    $ alvo_rcp_x = 590
    $ alvo_rcp_y = 620
    $ alvo_rcp_w = 130
    $ alvo_rcp_h = 150

    if etapa_rcp == "ritmo" and tempo_restante > 0.0:
        timer 0.1 repeat True action SetScreenVariable("tempo_restante", max(0.0, tempo_restante - 0.1))
    elif etapa_rcp == "ritmo" and tempo_restante <= 0.0:
        timer 0.01 action If(
            compressoes_certas >= 100 and compressoes_certas <= 120 and erros <= 5,
            Return("win"),
            Return("fail")
        )

    # Preenche a tela sem distorcer o paciente e centraliza o torax na area de procedimento.
    add Solid("#071016")
    add Transform("images/torax_rcp_acls.png", xsize=1920, ysize=1080) xpos -305
    add Solid("#0710162b")

    # A imagem responde fora do ponto adequado antes e durante as compressoes.
    button:
        xpos 0
        ypos 0
        xsize 1320
        ysize 1080
        background None
        hover_background None
        action If(
            etapa_rcp == "posicao",
            [
                SetScreenVariable("erros_posicao", erros_posicao + 1),
                SetScreenVariable("feedback_rcp", "Posicao inadequada. Localize o centro do torax, sobre a metade inferior do esterno.")
            ],
            [
                SetScreenVariable("erros", erros + 1),
                SetScreenVariable("alerta_posicao", True),
                SetScreenVariable("feedback_rcp", "Tecnica inadequada: as maos sairam do esterno.")
            ]
        )

    # Zona anatomica correta: metade inferior do esterno, sem marcador antes do acerto.
    button:
        xpos alvo_rcp_x
        ypos alvo_rcp_y
        xsize alvo_rcp_w
        ysize alvo_rcp_h
        background Solid("#00000000")
        hover_background Solid("#00000000")
        action If(
            etapa_rcp == "posicao",
            [
                SetScreenVariable("etapa_rcp", "ritmo"),
                SetScreenVariable("alerta_posicao", False),
                SetScreenVariable("feedback_rcp", "Posicao correta. Inicie as compressoes e mantenha 100 a 120 por minuto."),
                Stop("sound"),
                Play("rcp_voice", "audio/minijogos/acls/ritmo_rcp_110bpm.mp3", loop=True)
            ],
            [
                SetScreenVariable("compressoes_certas", compressoes_certas + 1),
                SetScreenVariable("alerta_posicao", False)
            ]
        )

    if etapa_rcp == "ritmo":
        frame:
            xpos alvo_rcp_x + 6
            ypos alvo_rcp_y + 6
            xsize alvo_rcp_w - 12
            ysize alvo_rcp_h - 12
            background Solid("#2ecc7140" if sinal_comprimir else "#2ecc7118")

    frame:
        xpos 1310
        ypos 0
        xsize 610
        yfill True
        background Frame(Solid("#071016f5"), 0, 0)
        padding (42, 44)

        vbox:
            spacing 22
            xfill True

            text "RCP DE ALTA QUALIDADE" size 34 bold True color "#00e5ff"
            text "PARADA EM FV / ADULTO" size 18 bold True color "#91a7b8"

            frame:
                xfill True
                background Frame(Solid("#101d29"), 6, 6)
                padding (22, 18)
                vbox:
                    spacing 8
                    text ("ETAPA 1 - POSICIONE AS MAOS" if etapa_rcp == "posicao" else "ETAPA 2 - RCP POR 1 MINUTO") size 23 bold True color "#ffffff"
                    text ("Centro do torax, metade inferior do esterno." if etapa_rcp == "posicao" else "Meta: 110 compressoes. Faixa adequada: 100-120/min.") size 19 color "#d4e0e8" line_spacing 4

            if etapa_rcp == "posicao":
                frame:
                    xfill True
                    yminimum 90
                    background Frame(Solid("#101d29"), 6, 6)
                    padding (20, 16)
                    vbox:
                        spacing 6
                        text "TENTATIVAS DE POSICAO" size 16 color "#91a7b8" bold True
                        text "[erros_posicao] erros" size 32 color ("#e74c3c" if erros_posicao else "#ffffff") bold True
            else:
                hbox:
                    spacing 12
                    frame:
                        xsize 248
                        ysize 108
                        background Frame(Solid("#101d29"), 6, 6)
                        padding (16, 13)
                        vbox:
                            spacing 5
                            text "COMPRESSOES" size 15 color "#91a7b8" bold True
                            text "[compressoes_certas] / 110" size 32 color "#2ecc71" bold True
                    frame:
                        xsize 248
                        ysize 108
                        background Frame(Solid("#101d29"), 6, 6)
                        padding (16, 13)
                        vbox:
                            spacing 5
                            text "TEMPO" size 15 color "#91a7b8" bold True
                            text "[tempo_restante:.1f] s" size 32 color "#f1c40f" bold True

                frame:
                    xfill True
                    yminimum 80
                    background Frame(Solid("#101d29"), 6, 6)
                    padding (20, 16)
                    hbox:
                        spacing 18
                        text "GUIA VISUAL" size 17 color "#91a7b8" bold True yalign 0.5
                        text ("COMPRIMA" if sinal_comprimir else "RETORNO") size 29 bold True color ("#2ecc71" if sinal_comprimir else "#f1c40f")

                frame:
                    xfill True
                    yminimum 72
                    background Frame(Solid("#101d29"), 6, 6)
                    padding (20, 13)
                    hbox:
                        spacing 18
                        text "RITMO MEDIO" size 16 color "#91a7b8" bold True yalign 0.5
                        text ("-- /min" if tempo_decorrido < 3.0 else "[ritmo_medio] /min") size 27 bold True color ("#2ecc71" if ritmo_medio >= 100 and ritmo_medio <= 120 else "#f1c40f")
                text "Toques fora do esterno: [erros] / 5 permitidos" size 16 color ("#e74c3c" if erros else "#91a7b8") bold True

            frame:
                xfill True
                yminimum 135
                background Frame(Solid("#132331"), 6, 6)
                padding (20, 18)
                vbox:
                    spacing 8
                    text "FEEDBACK" size 16 color "#00e5ff" bold True
                    if etapa_rcp == "posicao":
                        text feedback_rcp size 21 color "#ffffff" line_spacing 5 xmaximum 500
                    elif alerta_posicao:
                        text "Mãos fora do esterno. Retorne imediatamente ao centro do tórax." size 21 color "#e74c3c" line_spacing 5 xmaximum 500
                    elif tempo_decorrido < 3.0:
                        text "Inicie as compressoes sobre o esterno. O ritmo sera avaliado continuamente." size 21 color "#ffffff" line_spacing 5 xmaximum 500
                    elif ritmo_medio < 100:
                        text "Ritmo abaixo do recomendado. Acelere as compressoes mantendo o local correto." size 21 color "#f1c40f" line_spacing 5 xmaximum 500
                    elif ritmo_medio > 120:
                        text "Ritmo excessivo. Reduza a velocidade e permita o retorno completo do torax." size 21 color "#e74c3c" line_spacing 5 xmaximum 500
                    else:
                        text "Ritmo adequado. Continue no centro do torax e permita o retorno completo." size 21 color "#2ecc71" line_spacing 5 xmaximum 500

            null height 14
            text "Meta 110/min | Esterno | Retorno total do torax" size 17 color "#91a7b8" xalign 0.5 text_align 0.5

# --- MINIJOGO DE ESTABILIZAÇÃO PÉLVICA / CONTROLE DE HEMORRAGIA (ATLS) ---
screen minigame_pelvic_binder():
    zorder 110
    modal True

    default posicao_faixa = 0.0
    default indo_direita = True
    default tentativas = 0

    if tentativas < 3:
        timer 0.02 repeat True action [
            If(indo_direita,
               SetScreenVariable("posicao_faixa", posicao_faixa + 0.012),
               SetScreenVariable("posicao_faixa", posicao_faixa - 0.012)
            ),
            If(posicao_faixa >= 1.0, SetScreenVariable("indo_direita", False)),
            If(posicao_faixa <= 0.0, SetScreenVariable("indo_direita", True))
        ]

    add Solid("#0b1015f6")

    frame:
        align (0.5, 0.5)
        xsize 1120
        ysize 720
        background Frame(Solid("#1a252cf2"), 10, 10)
        padding (34, 32)

        vbox:
            spacing 24
            xfill True

            text "CONTROLE DE HEMORRAGIA: ESTABILIZAÇÃO PÉLVICA" size 28 bold True color "#00e5ff" xalign 0.5
            text "Posicione o binder sobre os grandes trocânteres. Muito alto não fecha o anel pélvico; muito baixo ou frouxo não controla o sangramento." size 20 color "#dbe7f1" xalign 0.5 text_align 0.5 line_spacing 4

            hbox:
                xalign 0.5
                spacing 70
                vbox:
                    spacing 5
                    text "TENTATIVAS" size 16 color "#b2bec3" xalign 0.5
                    text "[tentativas] / 3" size 34 color "#f1c40f" bold True xalign 0.5
                vbox:
                    spacing 5
                    text "ALVO CLÍNICO" size 16 color "#b2bec3" xalign 0.5
                    text "TROCÂNTERES" size 34 color "#2ecc71" bold True xalign 0.5

            frame:
                xalign 0.5
                xsize 900
                ysize 160
                background Solid("#26323a")

                frame:
                    xalign 0.5
                    ypos 0
                    xsize 260
                    ysize 160
                    background Solid("#2ecc71")
                    text "ZONA CORRETA\nGRANDES TROCÂNTERES" align (0.5, 0.5) size 20 color "#ffffff" bold True text_align 0.5

                frame:
                    xalign 0.18
                    ypos 0
                    xsize 120
                    ysize 160
                    background Solid("#e74c3c66")
                    text "ALTO" align (0.5, 0.5) size 18 color "#ffffff" bold True

                frame:
                    xalign 0.82
                    ypos 0
                    xsize 120
                    ysize 160
                    background Solid("#e74c3c66")
                    text "BAIXO" align (0.5, 0.5) size 18 color "#ffffff" bold True

                frame:
                    xalign posicao_faixa
                    ypos 0
                    xsize 22
                    ysize 160
                    background Solid("#f1c40f")

            button:
                xalign 0.5
                xsize 520
                ysize 92
                background Frame(Solid("#34495e"), 6, 6)
                hover_background Frame(Solid("#2ecc71"), 6, 6)
                action [
                    If(posicao_faixa >= 0.36 and posicao_faixa <= 0.64,
                       Return("win"),
                       [
                           SetScreenVariable("tentativas", tentativas + 1),
                           If(tentativas + 1 >= 3, Return("fail"))
                       ]
                    )
                ]
                text "FIXAR BINDER PÉLVICO" align (0.5, 0.5) size 27 color "#ffffff" bold True

# --- MINIJOGO DE DESCOMPRESSÃO TORÁCICA (ATLS / PNEUMOTÓRAX HIPERTENSIVO) ---
screen minigame_descompressao_torax():
    zorder 110
    modal True

    default tempo_restante = 14.0
    default erros_torax = 0
    default feedback_torax = "Identifique o lado e o ponto de descompressão antes da deterioração."
    default tentou_lado_errado = False
    default tentou_local_errado = False

    timer 0.1 repeat True action SetScreenVariable("tempo_restante", tempo_restante - 0.1)
    if tempo_restante <= 0:
        timer 0.01 action Return("fail")

    $ sat_simulada = max(72, int(88 - ((14.0 - tempo_restante) * 1.1)))
    $ pa_simulada = max(62, int(82 - ((14.0 - tempo_restante) * 1.2)))

    add Solid("#071016f7")

    hbox:
        align (0.5, 0.5)
        spacing 26

        frame:
            xsize 1110
            ysize 760
            background Frame(Solid("#101923f5"), 10, 10)
            padding (28, 26)

            vbox:
                spacing 14
                xfill True

                hbox:
                    spacing 18
                    frame:
                        xsize 92 ysize 82
                        background Frame(Solid("#e74c3c"), 8, 8)
                        text "B" align (0.5, 0.5) size 42 color "#071016" bold True
                    vbox:
                        yalign 0.5
                        spacing 4
                        text "PNEUMOTÓRAX HIPERTENSIVO" size 31 color "#ffffff" bold True
                        text "Instabilidade + hipoxemia + murmúrio reduzido à esquerda: trate clinicamente." size 18 color "#aebdcc"

                frame:
                    xfill True
                    ysize 78
                    background Frame(Solid("#0b1219"), 7, 7)
                    padding (18, 12)
                    hbox:
                        spacing 36
                        xalign 0.5
                        vbox:
                            spacing 2
                            text "TEMPO" size 13 color "#8fa6b8" bold True xalign 0.5
                            text "[tempo_restante:.1f]s" size 28 color ("#e74c3c" if tempo_restante < 5 else "#f1c40f") bold True xalign 0.5
                        vbox:
                            spacing 2
                            text "SAT O2" size 13 color "#8fa6b8" bold True xalign 0.5
                            text "[sat_simulada]%" size 28 color ("#e74c3c" if sat_simulada < 84 else "#f1c40f") bold True xalign 0.5
                        vbox:
                            spacing 2
                            text "PA" size 13 color "#8fa6b8" bold True xalign 0.5
                            text "[pa_simulada]/40" size 28 color "#e74c3c" bold True xalign 0.5
                        vbox:
                            spacing 2
                            text "ERROS" size 13 color "#8fa6b8" bold True xalign 0.5
                            text "[erros_torax] / 2" size 28 color ("#e74c3c" if erros_torax else "#2ecc71") bold True xalign 0.5

                frame:
                    xalign 0.5
                    xsize 1030
                    ysize 500
                    background Frame(Solid("#05080b"), 8, 8)
                    padding (0, 0)

                    fixed:
                        xysize (1030, 500)

                        add Transform("images/paciente.png", xsize=1030, ysize=580) xpos 0 ypos -40
                        add Solid("#07101622")

                        text "DIREITO" xpos 230 ypos 455 size 16 color "#d8e3ec" bold True outlines [(2, "#000000", 0, 0)]
                        text "ESQUERDO" xpos 665 ypos 455 size 16 color "#d8e3ec" bold True outlines [(2, "#000000", 0, 0)]

                        button:
                            xpos 638 ypos 288 xsize 148 ysize 112
                            background Solid("#2ecc7108")
                            hover_background Solid("#2ecc7155")
                            action Return("win")
                            tooltip "4º/5º espaço intercostal, linha axilar anterior/média esquerda"

                        button:
                            xpos 640 ypos 180 xsize 140 ysize 92
                            background Solid("#f1c40f08")
                            hover_background Solid("#f1c40f55")
                            action [
                                SetScreenVariable("erros_torax", erros_torax + 1),
                                SetScreenVariable("tentou_local_errado", True),
                                SetScreenVariable("feedback_torax", "Local alto demais para o ponto lateral preferido no trauma. Procure 4º/5º espaço no hemitórax esquerdo."),
                                If(erros_torax + 1 >= 2, Return("fail"))
                            ]

                        button:
                            xpos 250 ypos 288 xsize 150 ysize 112
                            background Solid("#e74c3c08")
                            hover_background Solid("#e74c3c55")
                            action [
                                SetScreenVariable("erros_torax", erros_torax + 1),
                                SetScreenVariable("tentou_lado_errado", True),
                                SetScreenVariable("feedback_torax", "Os achados são à esquerda: murmúrio reduzido e hipertimpanismo no hemitórax esquerdo."),
                                If(erros_torax + 1 >= 2, Return("fail"))
                            ]

                        button:
                            xpos 455 ypos 404 xsize 170 ysize 74
                            background Solid("#e74c3c08")
                            hover_background Solid("#e74c3c55")
                            action [
                                SetScreenVariable("erros_torax", erros_torax + 1),
                                SetScreenVariable("feedback_torax", "Abdome não descomprime pleura. Reavalie anatomia torácica antes que a hipóxia piore."),
                                If(erros_torax + 1 >= 2, Return("fail"))
                            ]

                frame:
                    xfill True
                    yminimum 68
                    background Frame(Solid("#132231"), 7, 7)
                    padding (18, 12)
                    text feedback_torax size 19 color "#ffffff" xalign 0.5 text_align 0.5 line_spacing 4

        frame:
            xsize 370
            ysize 760
            background Frame(Solid("#0b1219f2"), 10, 10)
            padding (22, 24)

            vbox:
                spacing 20
                xfill True

                text "RACIOCÍNIO ATLS" size 26 color "#00e5ff" bold True
                text "Não espere radiografia quando há ameaça imediata à ventilação e choque." size 20 color "#dbe7f1" line_spacing 4

                frame:
                    xfill True
                    background Frame(Solid("#142231"), 7, 7)
                    padding (16, 14)
                    vbox:
                        spacing 10
                        text "ACHADOS" size 15 color "#8fa6b8" bold True
                        text "• Trauma torácico fechado\n• SatO2 em queda\n• Murmúrio reduzido à esquerda\n• Hipertimpanismo\n• PA caindo" size 19 color "#ffffff" line_spacing 6

                frame:
                    xfill True
                    background Frame(Solid("#142231"), 7, 7)
                    padding (16, 14)
                    vbox:
                        spacing 10
                        text "CONDUTA ESPERADA" size 15 color "#8fa6b8" bold True
                        text "Descompressão imediata no hemitórax acometido, seguida de drenagem torácica definitiva." size 19 color "#ffffff" line_spacing 6

                text "Clique no ponto anatômico correto." size 18 color "#91a7b8" xalign 0.5 text_align 0.5

# --- MINIJOGO DE INTUBAÇÃO OROTRAQUEAL NO TRAUMA (ATLS) ---
screen minigame_iot_trauma():
    zorder 110
    modal True

    default etapa_iot = 0
    default erros_iot = 0
    default opcoes_iot = random.sample([
        ("Pré-oxigenar e checar material", 0),
        ("Estabilizar cervical em linha", 1),
        ("Visualizar glote e passar tubo", 2),
        ("Confirmar ETCO2 e ausculta", 3),
        ("Retirar colar e hiperestender", -1),
        ("Fixar tubo antes de confirmar", -1)
    ], 6)

    $ etapas = [
        ("Preparação", "Paciente hipoxêmico, Glasgow 8. A equipe aguarda sua primeira ordem antes da laringoscopia."),
        ("Proteção", "Material pronto. O colar será aberto, mas a coluna não pode perder alinhamento."),
        ("Inserção", "Campo preparado. Você tem visualização parcial da glote e precisa avançar com cuidado."),
        ("Confirmação", "Tubo introduzido. O próximo erro pode deixar uma intubação esofágica passar despercebida.")
    ]

    add Solid("#0b1015f6")

    frame:
        align (0.5, 0.5)
        xsize 1160
        ysize 720
        background Frame(Solid("#101923f4"), 10, 10)
        padding (34, 30)

        vbox:
            spacing 18
            xfill True

            hbox:
                xfill True
                spacing 18
                frame:
                    xsize 84
                    ysize 76
                    background Frame(Solid("#00e5ff"), 7, 7)
                    text "IOT" align (0.5, 0.5) size 30 color "#071016" bold True
                vbox:
                    spacing 4
                    text "PROCEDIMENTO: VIA AÉREA DEFINITIVA" size 29 bold True color "#ffffff"
                    text "Escolha a sequência correta. O painel não mostra a ordem; ele mostra o estado clínico atual." size 19 color "#9fb3c5"
                frame:
                    xalign 1.0
                    xsize 190
                    ysize 76
                    background Frame(Solid("#1d2d3b"), 7, 7)
                    vbox:
                        align (0.5, 0.5)
                        spacing 1
                        text "MARGEM DE ERRO" size 13 color "#8fa6b8" bold True xalign 0.5
                        text "[2 - erros_iot] / 2" size 28 color ("#e74c3c" if erros_iot >= 1 else "#2ecc71") bold True xalign 0.5

            frame:
                xalign 0.5
                xsize 1020
                ysize 92
                background Frame(Solid("#0b1219"), 7, 7)
                padding (22, 16)
                hbox:
                    spacing 20
                    text "ESTADO" size 16 color "#00e5ff" bold True yalign 0.5
                    text etapas[etapa_iot][1] size 21 color "#ffffff" yalign 0.5 line_spacing 4

            frame:
                xalign 0.5
                xsize 1020
                ysize 88
                background Frame(Solid("#162433"), 7, 7)
                padding (20, 14)
                hbox:
                    spacing 34
                    xalign 0.5
                    $ sat_iot = "88%%" if etapa_iot == 0 else ("91%%" if etapa_iot < 3 else "94%%")
                    $ cervical_iot = "RISCO" if etapa_iot <= 1 else "PROTEGIDA"
                    $ tubo_iot = "NÃO CONFIRMADO" if etapa_iot < 3 else "AGUARDA ETCO2"
                    vbox:
                        spacing 2
                        text "ETAPA" size 13 color "#8fa6b8" bold True xalign 0.5
                        text "[etapa_iot + 1] / 4" size 26 color "#00e5ff" bold True xalign 0.5
                    vbox:
                        spacing 2
                        text "SAT O2" size 13 color "#8fa6b8" bold True xalign 0.5
                        text sat_iot size 26 color ("#e74c3c" if etapa_iot == 0 else "#f1c40f") bold True xalign 0.5
                    vbox:
                        spacing 2
                        text "CERVICAL" size 13 color "#8fa6b8" bold True xalign 0.5
                        text cervical_iot size 26 color ("#e74c3c" if etapa_iot <= 1 else "#2ecc71") bold True xalign 0.5
                    vbox:
                        spacing 2
                        text "TUBO" size 13 color "#8fa6b8" bold True xalign 0.5
                        text tubo_iot size 24 color "#f1c40f" bold True xalign 0.5

            frame:
                xalign 0.5
                xsize 1020
                ysize 14
                background Solid("#26323a")
                bar:
                    value etapa_iot
                    range 4
                    xsize 1020
                    ysize 14
                    left_bar Solid("#2ecc71")
                    right_bar Solid("#26323a")

            grid 3 2:
                xalign 0.5
                xspacing 14
                yspacing 14

                for texto_acao, etapa_certa in opcoes_iot:
                    button:
                        xsize 322
                        ysize 92
                        background Frame(Solid("#132231e8"), 7, 7)
                        hover_background Frame(Solid("#34495e"), 7, 7)
                        action [
                            If(etapa_iot == etapa_certa,
                               If(etapa_iot == 3,
                                  Return("win"),
                                  SetScreenVariable("etapa_iot", etapa_iot + 1)
                               ),
                               [
                                   SetScreenVariable("erros_iot", erros_iot + 1),
                                   If(erros_iot + 1 >= 2, Return("fail"))
                               ]
                            )
                        ]
                        text texto_acao align (0.5, 0.5) size 18 color "#ffffff" bold True text_align 0.5

            text "Erros de sequência: [erros_iot] / 2" size 18 color ("#e74c3c" if erros_iot else "#8fa6b8") bold True xalign 0.5

# ==============================================================================
# 4. PERSONAGENS E IMAGENS
# ==============================================================================
transform slide_in_left:
    yalign 1.0 xalign 0.1
transform slide_in_right:
    yalign 1.0 xalign 0.95
transform entrada_suave_left:
    yalign 1.0
    xalign -0.08
    alpha 0.0
    easeout 0.8 xalign 0.08 alpha 1.0
transform entrada_suave_right:
    yalign 1.0
    xalign 1.08
    alpha 0.0
    easeout 0.8 xalign 0.94 alpha 1.0
transform pulso_luz:
    alpha 0.75
    linear 0.8 alpha 1.0
    linear 0.8 alpha 0.75
    repeat
transform zoom_abertura:
    zoom 1.05
    xalign 0.5
    yalign 0.5
    linear 6.0 zoom 1.0

define p = Character("[nome_jogador]", who_prefix="Dr(a). ")
define s = Character("NARRADOR / SISTEMA", color="#f1c40f", what_font="DejaVuSans-Bold.ttf")

define juliana = Character("Enfermeira Juliana", color="#1abc9c", image="juliana")
define clara = Character("Enfermeira Clara", color="#9b59b6", image="clara")
define marcos = Character("Dr. Marcos", color="#3498db", image="marcos")
define roberto = Character("Dr. Roberto", color="#34495e", image="roberto")
define osvaldo = Character("Sr. Osvaldo", color="#e67e22", what_italic=True)

# Imagens de fundo ajustadas
# Fundo da sala de reanimação neonatal
image bg sala_parto = Transform("images/fundo_neon.png", xsize=1920, ysize=1080)
image bg sala_vermelha = Transform("images/fundo_infa.jpg", xsize=1920, ysize=1080)
image bg corredor_plantao = Transform("images/entrada_h.png", xsize=1920, ysize=1080)
image bg recepcao_plantao = Transform("images/recepcao_h.png", xsize=1920, ysize=1080)
image bg trauma = Transform("images/trauma_bay.png", xsize=1920, ysize=1080)
image bg capa = Transform("images/capa.jpg", xsize=1920, ysize=1080)

image juliana normal = "juliana normal.png"
image clara normal = "clara normal.png"
image clara tensa = "clara tensa.png"
image marcos normal = "marcos normal.png"
image roberto normal = "roberto normal.png"

# DEFINIÇÃO DAS IMAGENS DE ECG COM MOLDURAS DUPLAS E TAMANHOS EXPANDIDOS
image ecg_infarto = Composite(
    (1240, 754),
    (0, 0), Solid("#000000", xsize=1240, ysize=754),
    (10, 10), Solid("#ffffff", xsize=1220, ysize=734),
    (20, 20), Transform("ecg_infarto.jpg", xsize=1200, ysize=714)
)

image monitor_fv = Composite(
    (1240, 309),
    (0, 0), Solid("#000000", xsize=1240, ysize=309),
    (10, 10), Solid("#ffffff", xsize=1220, ysize=289),
    (20, 20), Transform("monitor_fv.png", xsize=1200, ysize=269)
)

# ==============================================================================
# 5. LÓGICA DO JOGO (MENU PRINCIPAL)
# ==============================================================================
label start:
    # Mudança estratégica: Mostrar o fundo de capa durante a identificação do jogador
    scene bg capa with dissolve
    if not cadastro_realizado:
        call screen aviso_educacional

        python:
            nome_jogador = renpy.input("IDENTIFIQUE-SE, DOUTOR(A):", length=20).strip() or "Plantonista"
            matricula_jogador = renpy.input("MATRÍCULA OU EMAIL (Para o Banco de Dados):", length=30).strip() or "0000"
            cadastro_realizado = True

        s "Autenticação concluída. Acessando os módulos de simulação..."
    else:
        s "Cadastro já identificado. Retornando aos módulos de simulação..."

    if voz_jogador is None:
        call selecao_voz_jogador

    if not intro_plantao_vista:
        call abertura_plantao
        $ intro_plantao_vista = True

label escolha_caso:
    # Oculta qualquer janela de texto para exibir o novo dashboard moderno
    window hide
    call screen tela_selecao_casos
    $ escolha_final_caso = _return

    if escolha_final_caso == "caso_neo":
        jump caso_neonatal
    elif escolha_final_caso == "caso_acls":
        jump caso_batismo
    elif escolha_final_caso == "caso_atls":
        jump caso_politrauma

label selecao_voz_jogador:
    menu:
        "Escolha a voz do seu personagem:"
        "Voz feminina":
            $ voz_jogador = "feminina"
        "Voz masculina":
            $ voz_jogador = "masculina"
    return

label abertura_plantao:
    window hide
    scene black with fade
    centered "{color=#00e5ff}{size=48}06:54 - HOSPITAL METROPOLITANO{/size}{/color}\n{color=#a4b0be}{size=26}Centro de Simulação de Emergências{/size}{/color}"

    scene bg corredor_plantao at zoom_abertura with dissolve
    window show
    voice "audio/vozes/introducao/sistema/intro_sistema_001.mp3"
    s "A manhã ainda começa quando você atravessa a entrada do hospital para seu primeiro plantão no centro de simulação."
    voice "audio/vozes/introducao/sistema/intro_sistema_002.mp3"
    s "No crachá recém-entregue, seu nome aparece ao lado de uma função que exige decisões rápidas: plantonista."

    scene bg recepcao_plantao at zoom_abertura with dissolve
    show clara normal at entrada_suave_left
    voice "audio/vozes/introducao/clara/intro_clara_001.mp3"
    clara "Bom dia, Dr(a). [nome_jogador]. Eu sou Clara, enfermeira da equipe de simulação. As salas estão prontas e os monitores foram testados."

    if voz_jogador == "feminina":
        voice "audio/vozes/introducao/jogador/intro_jogador_feminino_001.mp3"
    else:
        voice "audio/vozes/introducao/jogador/intro_jogador_masculino_001.mp3"
    p "Certo. Que tipo de atendimento está previsto para hoje?"

    show marcos normal at entrada_suave_right
    voice "audio/vozes/introducao/marcos/intro_marcos_001.mp3"
    marcos "Eu sou Marcos, médico supervisor. Hoje você assumirá pacientes críticos desde a avaliação inicial até a estabilização."

    show expression Solid("#00e5ff22") as luz_radio at pulso_luz
    voice "audio/vozes/introducao/sistema/intro_sistema_003.mp3"
    s "Clara encosta o crachá no painel. As luzes de três setores se acendem: sala neonatal, box cardiológico e sala de trauma."
    hide luz_radio

    show clara tensa at slide_in_left
    voice "audio/vozes/introducao/clara/intro_clara_002.mp3"
    clara "Central de treinamento chamando. Há cenários disponíveis e cada um pode piorar rapidamente conforme suas decisões."

    voice "audio/vozes/introducao/marcos/intro_marcos_002.mp3"
    marcos "Os protocolos serão seu guia, mas a prioridade terá de ser reconhecida por você. Escolha o primeiro atendimento."

    voice "audio/vozes/introducao/sistema/intro_sistema_004.mp3"
    s "Você respira fundo, higieniza as mãos e se aproxima do painel de casos. O plantão de simulação começa agora."

    hide clara with dissolve
    hide marcos with dissolve
    scene bg capa with fade
    return


# ==============================================================================
#      CASO 1: REANIMAÇÃO NEONATAL EM SALA DE PARTO (SBP 2022)
# ==============================================================================
label caso_neonatal:
    # Variáveis Clínicas de Inicialização (Prematuro de 31 Semanas) - SBP 2022
    $ temp_neo = 36.8
    $ sato2_neo = 95
    $ fc_neo = 135
    $ ritmo_neo = "Sinusal"
    $ pontos = 1000

    # Checklist individual corrigido linha por linha para evitar erros de compilação
    $ check_preparacao = False
    $ check_passos_iniciais = False
    $ check_vpp = False
    $ check_intubacao = False
    $ check_massagem = False
    $ check_drogas_neo = False
    $ blender_correto = False

    # Carrega o fundo da sala de reanimação neonatal definido em 'bg sala_parto'
    scene bg sala_parto
    show screen neonatal_hud
    show screen botao_checklist_neonatal

    # Cena 1: O Alerta e Preparação de Sala
    voice "audio/vozes/neonatal/sistema/neo_sistema_001.mp3"
    s "O barulho do ar-condicionado é ofuscado pela pressa da equipe obstétrica. Você é o pediatra de plantão e o obstetra acaba de declarar indicação de cesárea de urgência por sofrimento fetal agudo."

    show juliana normal at slide_in_left
    voice "audio/vozes/neonatal/juliana/neo_juliana_001.mp3"
    juliana "Doutor(a), gestante de 31 semanas, parda, com pré-eclâmpsia grave. O líquido amniótico está claro no ultrassom. O bebê vai nascer em poucos minutos!"
    hide juliana with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/neonatal/roberto/neo_roberto_001.mp3"
    roberto "Excelente oportunidade para ver como você se comporta sob pressão, residente. Reanimação de um prematuro de 31 semanas exige precisão. Quais são suas primeiras ações de preparação da sala?"
    hide roberto with dissolve

label neo_preparacao_decisao:
    $ ultimo_checkpoint = "neo_preparacao_decisao"
    # --- RESET DE VITAIS DO CHECKPOINT ---
    $ temp_neo = 36.8
    $ sato2_neo = 95
    $ fc_neo = 135
    $ ritmo_neo = "Sinusal"
    $ check_preparacao = False
    # --------------------------------------
    menu:
        "PREPARAÇÃO DA SALA (Diretrizes SBP 2022):"
        "Garantir a temperatura da sala de parto entre 23-25ºC, ligar o berço radiante no máximo, preparar saco plástico transparente, touca dupla e ajustar o misturador (blender) para 30%% de O2.":
            $ check_preparacao = True
            $ blender_correto = True
            $ pontos += 100
            show roberto normal at slide_in_right
            voice "audio/vozes/neonatal/roberto/neo_roberto_002.mp3"
            roberto "Impecável. A sala deve ficar entre 23 e 25 graus. Para prematuros menores que 34 semanas, saco plástico e touca reduzem perda de calor. A VPP inicial deve começar com FiO2 de 30%%."
            hide roberto with dissolve
            voice "audio/vozes/neonatal/sistema/neo_sistema_002.mp3"
            s "{color=#00e5ff}Feedback educativo:{/color} em prematuros, prevenir hipotermia é intervenção de reanimação. A preparação da sala começa antes do nascimento."

        "Manter a temperatura da sala em 20ºC para evitar proliferação bacteriana, preparar toalhas aquecidas para secar vigorosamente o bebê e ajustar o oxigênio em 100%%.":
            $ pontos -= 250
            show roberto normal at slide_in_right
            voice "audio/vozes/neonatal/roberto/neo_roberto_003.mp3"
            roberto "Conduta perigosa. Temperatura de 20 graus favorece hipotermia. RN menor que 34 semanas não deve ser seco; deve ser envolto no saco plástico. E oxigênio a 100%% no início aumenta risco de lesão por estresse oxidativo."
            hide roberto with dissolve
            jump game_over_neonatal

        "Ajustar a temperatura da sala para 26ºC, separar cânula traqueal de tamanho 3.5 com balonete e deixar o oxigênio em ar ambiente (21%%).":
            $ pontos -= 200
            show roberto normal at slide_in_right
            voice "audio/vozes/neonatal/roberto/neo_roberto_004.mp3"
            roberto "Incorreto. A sala deve ficar entre 23 e 25 graus. Cânula 3.5 com balonete não é indicada para um prematuro de 31 semanas. E a FiO2 inicial, nesse caso, deve ser 30%%."
            hide roberto with dissolve
            jump game_over_neonatal

    # Cena 2: O Nascimento e Estabilização Térmica
    voice "audio/vozes/neonatal/sistema/neo_sistema_003.mp3"
    s "O obstetra retira o recém-nascido. Juliana segura o bebê."

    show juliana normal at slide_in_left
    voice "audio/vozes/neonatal/juliana/neo_juliana_002.mp3"
    juliana "Nasceu! Prematuro de 31 semanas, masculino, flácido, em apneia e sem choro!"
    hide juliana with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/neonatal/roberto/neo_roberto_005.mp3"
    roberto "O Minuto de Ouro começou. O bebê está na sua mão, residente. Conduta imediata de estabilização!"
    hide roberto with dissolve

label neo_estabilizacao_decisao:
    $ ultimo_checkpoint = "neo_estabilizacao_decisao"
    # --- RESET DE VITAIS DO CHECKPOINT ---
    $ temp_neo = 36.8
    $ sato2_neo = 95
    $ fc_neo = 135
    $ check_passos_iniciais = False
    # --------------------------------------
    menu:
        "ESTABILIZAÇÃO INICIAL EM <34s (Até 30 segundos de vida):"
        "Levar imediatamente ao berço radiante, envolvê-lo no saco plástico transparente sem secar, colocar touca dupla, posicionar a cabeça em leve extensão e avaliar vitais.":
            $ check_passos_iniciais = True
            $ pontos += 150
            $ temp_neo = 36.7
            show juliana normal at slide_in_left
            voice "audio/vozes/neonatal/juliana/neo_juliana_003.mp3"
            juliana "Passos iniciais concluídos! O bebê está envolto no plástico e com a touca. Temperatura corporal estável em 36.7ºC."
            hide juliana with dissolve

        "Secar o corpo inteiro com as toalhas aquecidas, remover as toalhas úmidas, aspirar rotineiramente a boca e as narinas com sonda de aspiração e avaliar vitais.":
            $ pontos -= 300
            $ temp_neo = 35.1 # Hipotermia grave por evaporação
            $ fc_neo = 75
            $ sato2_neo = 80
            show roberto normal at slide_in_right
            voice "audio/vozes/neonatal/roberto/neo_roberto_006.mp3"
            roberto "Erro grave. Ao secar o prematuro menor que 34 semanas, você aumentou a perda de calor e levou a temperatura para 35,1 graus. Além disso, aspirar vias aéreas sem obstrução visível pode causar bradicardia."
            hide roberto with dissolve
            jump game_over_neonatal

    # Avaliação Clínica dos Primeiros 30 Segundos
    $ fc_neo = 70
    $ sato2_neo = 60
    $ ritmo_neo = "Bradicardia"
    voice "audio/vozes/neonatal/sistema/neo_sistema_004.mp3"
    s "Vias aéreas posicionadas em leve extensão. O bebê foi estimulado gentilmente duas vezes tocando a planta dos pés."

    show juliana normal at slide_in_left
    voice "audio/vozes/neonatal/juliana/neo_juliana_004.mp3"
    juliana "Doutor(a), passados 30 segundos, o bebê continua em apneia! Ausculta cardíaca revela bradicardia severa. Frequência cardíaca de 70 bpm! SatO2 pré-ductal em 60%%!"
    hide juliana with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/neonatal/roberto/neo_roberto_007.mp3"
    roberto "Bradicardia e apneia persistem. O Minuto de Ouro está terminando. Qual é a conduta imediata pelo protocolo?"
    hide roberto with dissolve

label neo_vpp_decisao:
    $ ultimo_checkpoint = "neo_vpp_decisao"
    # --- RESET DE VITAIS DO CHECKPOINT ---
    $ temp_neo = 36.7
    $ fc_neo = 70
    $ sato2_neo = 60
    $ ritmo_neo = "Bradicardia"
    $ check_vpp = False
    # --------------------------------------
    menu:
        "INTERVENÇÃO CRÍTICA (Golden Minute):"
        "Iniciar Ventilação com Pressão Positiva (VPP) usando máscara facial acoplada ao ventilador em T com FiO2 a 30%%, PEEP de 5 e PIP de 20-25 cmH2O.":
            $ check_vpp = True
            $ pontos += 150

            show juliana normal at slide_in_left
            voice "audio/vozes/neonatal/juliana/neo_juliana_005.mp3"
            juliana "VPP iniciada com ventilador em T a 30%% de oxigênio!"
            hide juliana with dissolve

            voice "audio/vozes/neonatal/sistema/neo_sistema_005.mp3"
            s "Juliana acopla a máscara. Você deve assumir as ventilações manuais guiando-se pelo áudio rítmico oficial."

            # --- MINIJOGO DO RITMO DE VPP 'APERTA, SOLTA, SOLTA' ---
            voice "audio/vozes/neonatal/sistema/neo_sistema_006.mp3"
            s "Prepare-se! O ritmo da SBP é contínuo e compassado: 'Aperta, Solta, Solta...'"

            # O áudio agora é gerenciado de forma 100% interna e precisa pela screen para evitar descompassos
            call screen minigame_vpp_neonatal

            if _return == "win":
                $ pontos += 150
                voice "audio/vozes/neonatal/sistema/neo_sistema_007.mp3"
                s "VPP com ritmo excelente! Você entregou a pressão correta e permitiu a expiração passiva do prematuro nos tempos corretos."
                voice "audio/vozes/neonatal/sistema/neo_sistema_008.mp3"
                s "{color=#00e5ff}Feedback educativo:{/color} na reanimação neonatal, ventilação eficaz costuma ser a manobra que mais recupera a frequência cardíaca."
            else:
                $ pontos -= 250
                voice "audio/vozes/neonatal/sistema/neo_sistema_009.mp3"
                s "Erro de ventilação! Seus apertos foram rápidos ou longos demais, gerando volutrauma severo e falha circulatória por hiperinsuflação."
                jump game_over_neonatal

        "Instalar cateter de oxigênio nasal em alto fluxo com FiO2 a 100%% e continuar massageando as costas do bebê.":
            $ pontos -= 300
            show roberto normal at slide_in_right
            voice "audio/vozes/neonatal/roberto/neo_roberto_008.mp3"
            roberto "Conduta inadequada. Oxigênio livre não resolve apneia com bradicardia. O tratamento necessário agora é ventilação com pressão positiva."
            hide roberto with dissolve
            jump game_over_neonatal

    # Reavaliação após o primeiro ciclo de VPP
    $ fc_neo = 55
    $ sato2_neo = 58
    $ ritmo_neo = "Bradicardia"
    voice "audio/vozes/neonatal/sistema/neo_sistema_010.mp3"
    s "Durante a VPP, Juliana posiciona o oxímetro de pulso."

    show juliana normal at slide_in_left
    voice "audio/vozes/neonatal/juliana/neo_juliana_006.mp3"
    juliana "Oxímetro de pulso colocado no membro superior direito (pré-ductal) e eletrodos do ECG fixados! Frequência cardíaca no monitor do ECG mostra 55 bpm e o tórax não está expandindo adequadamente!"
    hide juliana with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/neonatal/roberto/neo_roberto_009.mp3"
    roberto "Bradicardia abaixo de 60 bpm e tórax imóvel. O que está falhando? Lembre-se do MR. SOPA! Se os passos de ajuste falharem, qual é a próxima conduta de via aérea avançada?"
    hide roberto with dissolve

label neo_intubacao_decisao:
    $ ultimo_checkpoint = "neo_intubacao_decisao"
    # --- RESET DE VITAIS DO CHECKPOINT ---
    $ temp_neo = 36.7
    $ fc_neo = 55
    $ sato2_neo = 58
    $ check_intubacao = False
    # --------------------------------------
    menu:
        "VIA AÉREA AVANÇADA (Diretrizes SBP):"
        "Proceder imediatamente à intubação orotraqueal, utilizando lâmina reta número 00 ou 0 e cânula sem balonete diâmetro 3.0.":
            $ check_intubacao = True
            $ pontos += 150

            show juliana normal at slide_in_left
            voice "audio/vozes/neonatal/juliana/neo_juliana_007.mp3"
            juliana "Preparando laringoscópio reta número 0 e tubo 3.0!"
            hide juliana with dissolve

            $ pontos += 100
            voice "audio/vozes/neonatal/sistema/neo_sistema_011.mp3"
            s "A equipe realiza a intubação orotraqueal sob sua indicação. Cânula 3.0 sem balonete introduzida. A posição é confirmada por expansibilidade torácica, ausculta bilateral e melhora da ventilação."
            voice "audio/vozes/neonatal/sistema/neo_sistema_012.mp3"
            s "{color=#00e5ff}Feedback educativo:{/color} via aérea avançada é indicada quando a VPP por máscara não expande o tórax ou não melhora a bradicardia persistente."

        "Iniciar massagem cardíaca externa imediatamente através da técnica dos dois polegares, mantendo a ventilação por máscara.":
            $ pontos -= 300
            show roberto normal at slide_in_right
            voice "audio/vozes/neonatal/roberto/neo_roberto_010.mp3"
            roberto "Erro de sequência. Se a VPP por máscara não expande o tórax, você precisa corrigir a via aérea antes das compressões. A massagem não compensa uma ventilação ineficaz."
            hide roberto with dissolve
            jump game_over_neonatal

    # Tubo posicionado
    $ fc_neo = 48
    $ sato2_neo = 55
    voice "audio/vozes/neonatal/sistema/neo_sistema_013.mp3"
    s "Tubo fixado em 7 cm na rima labial. Ausculta pulmonar bilateral simétrica."

    show juliana normal at slide_in_left
    voice "audio/vozes/neonatal/juliana/neo_juliana_008.mp3"
    juliana "Recém-nascido intubado com sucesso. Ventilando com FiO2 a 100%%. Mesmo assim, após 30 segundos de ventilação eficaz, a frequência cardíaca segue em 48 bpm."
    hide juliana with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/neonatal/roberto/neo_roberto_011.mp3"
    roberto "Bradicardia abaixo de 60 bpm mantida mesmo após ventilação por tubo traqueal com oxigênio a 100%%. Agora é o momento! Qual a conduta de ressuscitação mecânica coordenada?"
    hide roberto with dissolve

label neo_massagem_decisao:
    $ ultimo_checkpoint = "neo_massagem_decisao"
    # --- RESET DE VITAIS DO CHECKPOINT ---
    $ temp_neo = 36.7
    $ fc_neo = 48
    $ sato2_neo = 55
    $ check_massagem = False
    # --------------------------------------
    menu:
        "RESSUSCITAÇÃO CARDIOPULMONAR NEONATAL (3:1):"
        "Iniciar massagem cardíaca externa coordenada com a ventilação na proporção de 3:1 (3 compressões para 1 ventilação), utilizando a técnica dos dois polegares circundando o tórax.":
            $ check_massagem = True
            $ pontos += 150

            voice "audio/vozes/neonatal/sistema/neo_sistema_014.mp3"
            s "Inicie o ciclo coordenado. O ritmo estrito da SBP exige sincronia: 'Um, Dois, Três, Ventila!'"

            # --- MINIJOGO DE RCP NEONATAL COORDENADA 3:1 ---
            call screen minigame_rcp_neonatal
            if _return == "win":
                $ pontos += 150
                voice "audio/vozes/neonatal/sistema/neo_sistema_015.mp3"
                s "Excelente coordenação mecânica! Você manteve a proporção de 3:1 sem atrasos na ventilação."
                voice "audio/vozes/neonatal/sistema/neo_sistema_016.mp3"
                s "{color=#00e5ff}Feedback educativo:{/color} no recém-nascido, a proporção 3:1 prioriza ventilação porque a causa mais comum da parada é hipóxia."
            else:
                $ pontos -= 250
                voice "audio/vozes/neonatal/sistema/neo_sistema_017.mp3"
                s "Falha de coordenação! A ventilação ocorreu simultaneamente à compressão, anulando o gradiente de pressão intratorácico e gerando barotrauma severo."
                jump game_over_neonatal

        "Iniciar massagem cardíaca na proporção de 15:2 com a técnica de dois dedos no centro do esterno, mantendo o oxigênio a 30%%.":
            $ pontos -= 300
            show roberto normal at slide_in_right
            voice "audio/vozes/neonatal/roberto/neo_roberto_012.mp3"
            roberto "Erro de protocolo. Quinze para dois e trinta para dois não são as proporções da reanimação neonatal em sala de parto. Aqui, a proporção é três compressões para uma ventilação, com FiO2 a 100%%."
            hide roberto with dissolve
            jump game_over_neonatal

    # Reavaliação após 60 segundos de RCP de alta qualidade
    $ fc_neo = 45
    $ sato2_neo = 55
    voice "audio/vozes/neonatal/sistema/neo_sistema_018.mp3"
    s "Um minuto completo de compressões e ventilações coordenadas a 100%% de oxigênio é concluído."

    show juliana normal at slide_in_left
    voice "audio/vozes/neonatal/juliana/neo_juliana_009.mp3"
    juliana "Doutor(a), reavaliando a frequência cardíaca pelo ECG... Frequência cardíaca ainda em bradicardia persistente de 45 bpm! Não houve resposta!"
    hide juliana with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/neonatal/roberto/neo_roberto_013.mp3"
    roberto "Bradicardia refratária a choque mecânico e massagem coordenada. Precisamos introduzir a via medicamentosa urgentemente. Qual a via de escolha e a dosagem da droga de ressuscitação?"
    hide roberto with dissolve

label neo_drogas_decisao:
    $ ultimo_checkpoint = "neo_drogas_decisao"
    # --- RESET DE VITAIS DO CHECKPOINT ---
    $ temp_neo = 36.7
    $ fc_neo = 45
    $ sato2_neo = 55
    $ check_drogas_neo = False
    # --------------------------------------
    menu:
        "DROGAS DE RESSUSCITAÇÃO NEONATAL (Acesso e Dosagem):"
        "Realizar cateterismo venoso umbilical de urgência e administrar Adrenalina na diluição de 1:10.000, na dose de 0,01 a 0,03 mg/kg IV rápido.":
            $ check_drogas_neo = True
            $ pontos += 200

            show juliana normal at slide_in_left
            voice "audio/vozes/neonatal/juliana/neo_juliana_010.mp3"
            juliana "Preparando o cateter umbilical e a solução de Adrenalina 1:10.000!"
            hide juliana with dissolve

            $ pontos += 150
            voice "audio/vozes/neonatal/sistema/neo_sistema_019.mp3"
            s "Injetando Adrenalina 1:10.000 através do cateter venoso umbilical... Membro elevado e lavado com flush fisiológico."
            voice "audio/vozes/neonatal/sistema/neo_sistema_020.mp3"
            s "{color=#00e5ff}Feedback educativo:{/color} adrenalina IV por cateter umbilical é a via preferencial quando a bradicardia persiste apesar de ventilação eficaz e compressões."
            jump neo_salvamento_final

        "Infundir Adrenalina na dose de 0,1 mg/kg direto no tubo traqueal (intratecal) e aplicar um bolus de soro fisiológico de 20 mL/kg.":
            $ pontos -= 300
            show roberto normal at slide_in_right
            voice "audio/vozes/neonatal/roberto/neo_roberto_014.mp3"
            roberto "Erro de conduta. A via preferencial é o cateter venoso umbilical. Além disso, bolus hídrico de rotina sem suspeita de perda volêmica pode piorar um coração já comprometido."
            hide roberto with dissolve
            jump game_over_neonatal

label neo_salvamento_final:
    # O Clímax do Sucesso Clínico (O bebê só é salvo aqui no final absoluto!)
    voice "audio/vozes/neonatal/sistema/neo_sistema_022.mp3"
    s "Alguns segundos após a infusão de Adrenalina... o monitor do ECG começa a apresentar comportamento estável."

    $ fc_neo = 140
    $ sato2_neo = 94
    $ ritmo_neo = "Sinusal"

    show juliana normal at slide_in_left
    voice "audio/vozes/neonatal/juliana/neo_juliana_011.mp3"
    juliana "Doutor(a)! Veja o monitor! A frequência cardíaca disparou para 140 bpm! O bebê está respirando e começando a apresentar tônus muscular!"
    hide juliana with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/neonatal/roberto/neo_roberto_015.mp3"
    roberto "Excelente. Você coordenou a reanimação neonatal, ventilou, escalonou a via aérea, fez compressões no ritmo correto e usou adrenalina pela via adequada. Esse recém-nascido agora precisa de cuidados intensivos."
    hide roberto with dissolve

    hide screen neonatal_hud
    hide screen botao_checklist_neonatal
    scene black with fade

    # Salva o resultado do caso neonatal de sucesso no Firebase
    $ salvar_no_banco(nome_jogador, matricula_jogador, pontos, "Reanimacao_Neonatal_SBP", "Sucesso")

    call screen debriefing_simples(
        "CASO NEONATAL CONCLUÍDO",
        "Sucesso",
        "Recém-nascido salvo e estabilizado para encaminhamento à UTI neonatal",
        pontos,
        "SBP 2022 - Reanimação Neonatal",
        [
            "Você iniciou com sala aquecida, saco plástico, touca e FiO2 inicial adequada para <34 semanas.",
            "Quando apneia e FC baixa persistiram, priorizou VPP efetiva antes de compressões.",
            "Escalonou para intubação orotraqueal, compressões 3:1 e adrenalina IV por cateter umbilical quando a bradicardia seguiu refratária."
        ],
        "Debriefing: sua conduta respeitou a lógica da reanimação neonatal. O ponto forte foi não pular etapas: primeiro termorregulação e ventilação, depois via aérea avançada, compressões e droga apenas quando havia indicação."
    )
    jump escolha_caso

# ==============================================================================
#                      TELA DE FALHA (NEONATAL GAME OVER)
# ==============================================================================

label game_over_neonatal:
    $ ritmo_neo = "Assistolia"
    $ fc_neo = 0
    with hpunch

    show juliana normal at slide_in_left
    voice "audio/vozes/neonatal/juliana/neo_juliana_012.mp3"
    juliana "Doutor(a)... sem pulso no cordão umbilical. O eletrocardiograma mostra linha reta. Assistolia neonatal."
    hide juliana with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/neonatal/roberto/neo_roberto_016.mp3"
    roberto "Reanimação neonatal não tolera desvios importantes da sequência. Um atraso no Minuto de Ouro ou um erro de dose pode ser fatal em um prematuro. Infelizmente, nós o perdemos."
    hide roberto with dissolve

    $ hora_obito_neo = renpy.time.strftime("%H:%M:%S")
    voice "audio/vozes/neonatal/sistema/neo_sistema_023.mp3"
    s "O óbito do recém-nascido é declarado às [hora_obito_neo] horas na sala de parto."

    hide screen neonatal_hud
    hide screen botao_checklist_neonatal
    scene black with fade

    # Envia o score de falha para o seu Firebase
    $ salvar_no_banco(nome_jogador, matricula_jogador, 0, "Reanimacao_Neonatal_SBP", "Falha")

    call screen debriefing_simples(
        "DEBRIEFING DO CASO NEONATAL",
        "Falha",
        "Óbito do recém-nascido declarado na sala de parto",
        0,
        "SBP 2022 - Reanimação Neonatal",
        [
            "Compare sua escolha com a sequência SBP: preparo térmico, passos iniciais e VPP efetiva no Minuto de Ouro.",
            "Se a FC não sobe, o problema mais comum é ventilação ineficaz ou via aérea mal posicionada.",
            "Compressões e adrenalina não compensam uma ventilação inicial inadequada."
        ],
        "Debriefing: a deterioração ocorreu porque uma etapa crítica foi antecipada, atrasada ou executada fora da sequência. No RN deprimido, a intervenção que mais muda o desfecho é ventilação eficaz e precoce."
    )

    call screen menu_pos_falha(
        "FALHA CRÍTICA",
        "O recém-nascido evoluiu para óbito. Escolha como deseja prosseguir no treinamento."
    )
    $ escolha_pos_falha = _return

    if escolha_pos_falha == "retry":
        $ renpy.jump(ultimo_checkpoint)
    elif escolha_pos_falha == "casos":
        jump escolha_caso
    else:
        $ renpy.quit()


# ==============================================================================
#               CASO 3: POLITRAUMA - AVALIAÇÃO PRIMÁRIA ATLS
# ==============================================================================
label caso_politrauma:
    $ pa_trauma = "82/48"
    $ pa_sistolica_trauma = 82
    $ sato2_trauma = 88
    $ fc_trauma = 132
    $ glasgow_trauma = 8
    $ temp_trauma = 35.8
    $ prioridade_trauma = "A - VIA AÉREA"
    $ pontos = 1000

    $ check_trauma_a = False
    $ check_trauma_b = False
    $ check_trauma_c = False
    $ check_trauma_d = False
    $ check_trauma_e = False
    $ check_trauma_adj = False

    scene bg trauma
    show screen trauma_hud
    show screen botao_checklist_trauma

    voice "audio/vozes/trauma/sistema/trauma_sistema_001.mp3"
    s "O rádio aciona trauma nível 1. Vítima de colisão moto-carro, masculino, 27 anos, arremessado a cerca de 8 metros. Chega imobilizado, com capacete removido pelo SAMU e colar cervical improvisado."

    show clara tensa at slide_in_left
    voice "audio/vozes/trauma/clara/trauma_clara_001.mp3"
    clara "Doutor(a), ele chega pálido, sudoreico e rebaixado. PA 82 por 48, FC 132, SatO2 88%% em máscara simples, Glasgow 8. Há deformidade pélvica e murmúrio vesicular reduzido à esquerda."
    hide clara with dissolve

    show marcos normal at slide_in_left
    voice "audio/vozes/trauma/marcos/trauma_marcos_001.mp3"
    marcos "Sem hemorragia externa maciça visível. Eu assumo a estabilização cervical manual e preparo a via aérea."
    hide marcos with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/trauma/roberto/trauma_roberto_001.mp3"
    roberto "Este é um atendimento ATLS clássico. A prioridade é reconhecer e tratar ameaças imediatas à vida. Comece pela avaliação primária: A, B, C, D, E."
    hide roberto with dissolve

label trauma_a_decisao:
    $ ultimo_checkpoint = "trauma_a_decisao"
    $ prioridade_trauma = "A - VIA AÉREA"
    $ check_trauma_a = False
    call screen menu_atls("A - VIA AÉREA COM PROTEÇÃO CERVICAL", [
        ("Glasgow 8 e hipoxemia: pré-oxigenar, manter estabilização cervical manual e realizar via aérea definitiva com sequência controlada.", "iot"),
        ("Sentar o paciente para melhorar a respiração e retirar o colar cervical para facilitar a fala.", "sentar"),
        ("Pedir TC de crânio imediatamente para investigar o Glasgow 8 antes de controlar a via aérea.", "tc")
    ])
    $ escolha_trauma = _return

    if escolha_trauma == "iot":
        $ check_trauma_a = True
        $ pontos += 120
        voice "audio/vozes/trauma/sistema/trauma_sistema_002.mp3"
        s "A equipe prepara intubação orotraqueal com estabilização cervical manual. Execute a sequência sem hiperestender o pescoço e confirme o tubo."

        call screen minigame_iot_trauma
        if _return == "win":
            $ pontos += 140
            $ sato2_trauma = 90
            show clara normal at slide_in_left
            voice "audio/vozes/trauma/clara/trauma_clara_002.mp3"
            clara "Tubo confirmado com capnografia e ausculta bilateral. SatO2 subiu parcialmente para 90%%, mas o hemitórax esquerdo continua ventilando mal."
            hide clara with dissolve
            show roberto normal at slide_in_right
            voice "audio/vozes/trauma/roberto/trauma_roberto_002.mp3"
            roberto "Excelente. No trauma, via aérea definitiva não pode custar proteção cervical. Pré-oxigenação, estabilização manual e confirmação por capnografia fazem parte do procedimento."
            hide roberto with dissolve
            voice "audio/vozes/trauma/sistema/trauma_sistema_003.mp3"
            s "{color=#00e5ff}Feedback educativo:{/color} no ATLS, A significa via aérea com proteção cervical. Após intubar, confirme o tubo e reavalie oxigenação."
        else:
            $ pontos -= 260
            voice "audio/vozes/trauma/sistema/trauma_sistema_004.mp3"
            s "A sequência de intubação falhou. Houve perda da proteção cervical ou ausência de confirmação adequada do tubo."
            jump trauma_game_over

    elif escolha_trauma == "sentar":
        $ pontos -= 250
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_003.mp3"
        roberto "Erro grave. Em trauma de alta energia, coluna cervical deve ser protegida até avaliação adequada. Movimentar e retirar proteção cervical sem critério pode agravar lesão medular."
        hide roberto with dissolve
        jump trauma_game_over

    elif escolha_trauma == "tc":
        $ pontos -= 200
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_004.mp3"
        roberto "Sequência errada. Glasgow 8 com hipoxemia exige controle de via aérea antes da tomografia. Exame definitivo não vem antes de ameaça imediata à vida."
        hide roberto with dissolve
        jump trauma_game_over

    $ prioridade_trauma = "B - RESPIRAÇÃO"
    voice "audio/vozes/trauma/sistema/trauma_sistema_005.mp3"
    s "Com a via aérea controlada e a coluna protegida, você reavalia o B. O hemitórax esquerdo expande pouco, a percussão é hipertimpânica e a pressão segue baixa."

label trauma_b_decisao:
    $ ultimo_checkpoint = "trauma_b_decisao"
    $ prioridade_trauma = "B - RESPIRAÇÃO"
    $ check_trauma_b = False
    call screen menu_atls("B - RESPIRAÇÃO E VENTILAÇÃO", [
        ("Suspeitar de pneumotórax hipertensivo à esquerda e realizar descompressão imediata, seguida de drenagem torácica, sem aguardar radiografia.", "descompressao"),
        ("Aguardar radiografia de tórax para confirmar o diagnóstico antes de qualquer intervenção.", "rx"),
        ("Aumentar ventilação com pressão positiva e deixar a avaliação do tórax para depois.", "pressao")
    ])
    $ escolha_trauma = _return

    if escolha_trauma == "descompressao":
        $ check_trauma_b = True
        $ pontos += 160
        $ sato2_trauma = 95
        $ pa_trauma = "90/54"
        $ pa_sistolica_trauma = 90
        show clara normal at slide_in_left
        voice "audio/vozes/trauma/clara/trauma_clara_003.mp3"
        clara "Descompressão realizada à esquerda. A saturação subiu para 95%% e a expansibilidade melhorou. Preparando drenagem torácica definitiva."
        hide clara with dissolve
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_005.mp3"
        roberto "Boa. Pneumotórax hipertensivo é diagnóstico clínico em paciente instável e exige tratamento imediato. A radiografia não deve atrasar a descompressão."
        hide roberto with dissolve
        voice "audio/vozes/trauma/sistema/trauma_sistema_006.mp3"
        s "{color=#00e5ff}Feedback educativo:{/color} sinais clínicos de pneumotórax hipertensivo em instabilidade indicam descompressão imediata, seguida de drenagem definitiva."

    elif escolha_trauma == "rx":
        $ pontos -= 300
        $ sato2_trauma = 72
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_006.mp3"
        roberto "Erro crítico. Instabilidade, hipertimpanismo, hipoxemia e piora hemodinâmica exigem descompressão imediata. A radiografia não vem antes da vida."
        hide roberto with dissolve
        jump trauma_game_over

    elif escolha_trauma == "pressao":
        $ pontos -= 250
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_007.mp3"
        roberto "Cuidado. Ventilação com pressão positiva em pneumotórax hipertensivo não tratado pode piorar rapidamente a instabilidade. Trate a ameaça torácica agora."
        hide roberto with dissolve
        jump trauma_game_over

    $ prioridade_trauma = "C - CIRCULAÇÃO"
    voice "audio/vozes/trauma/sistema/trauma_sistema_007.mp3"
    s "Com a respiração melhorando, a pressão continua baixa e a frequência cardíaca segue elevada. A pelve é dolorosa e instável. Há escoriações extensas, sem sangramento externo maciço."

label trauma_c_decisao:
    $ ultimo_checkpoint = "trauma_c_decisao"
    $ prioridade_trauma = "C - CIRCULAÇÃO"
    $ check_trauma_c = False
    call screen menu_atls("C - CIRCULAÇÃO E CONTROLE DE HEMORRAGIA", [
        ("Aplicar estabilização pélvica, obter dois acessos calibrosos ou intraósseo, ativar transfusão maciça e controlar hemorragia antes de TC.", "binder"),
        ("Infundir 2 litros de soro fisiológico rapidamente e aguardar melhora antes de acionar banco de sangue.", "soro"),
        ("Levar para tomografia de corpo inteiro agora para localizar a fonte do sangramento.", "tc")
    ])
    $ escolha_trauma = _return

    if escolha_trauma == "binder":
        $ check_trauma_c = True
        $ pontos += 180
        voice "audio/vozes/trauma/sistema/trauma_sistema_008.mp3"
        s "A pelve instável precisa de compressão externa correta. Posicione o binder na altura dos grandes trocânteres para reduzir o volume pélvico e ajudar no controle da hemorragia."

        call screen minigame_pelvic_binder
        if _return == "win":
            $ pontos += 120
            voice "audio/vozes/trauma/sistema/trauma_sistema_009.mp3"
            s "Binder pélvico bem posicionado. A compressão reduz o volume pélvico e ajuda a limitar o sangramento."
        else:
            $ pontos -= 220
            voice "audio/vozes/trauma/sistema/trauma_sistema_010.mp3"
            s "Binder mal posicionado. A estabilização não reduziu o volume pélvico e o sangramento continuou."
            jump trauma_game_over

        $ pa_trauma = "98/60"
        $ pa_sistolica_trauma = 98
        $ fc_trauma = 118
        show clara normal at slide_in_left
        voice "audio/vozes/trauma/clara/trauma_clara_004.mp3"
        clara "Binder pélvico aplicado. Dois acessos 14G funcionantes. Hemoderivados chegando. A pressão subiu para 98 por 60."
        hide clara with dissolve
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_008.mp3"
        roberto "Excelente. Choque no trauma é hemorragia até prova em contrário. Controle mecânico, acesso, hemoderivados e cirurgia precoce quando indicada."
        hide roberto with dissolve
        voice "audio/vozes/trauma/sistema/trauma_sistema_011.mp3"
        s "{color=#00e5ff}Feedback educativo:{/color} no choque hemorrágico, controle de sangramento e ressuscitação hemostática são mais importantes que grandes volumes de cristaloide."

    elif escolha_trauma == "soro":
        $ pontos -= 250
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_009.mp3"
        roberto "Conduta inadequada para choque hemorrágico. Cristaloide excessivo dilui fatores de coagulação, piora hipotermia e não substitui sangue em hemorragia importante."
        hide roberto with dissolve
        jump trauma_game_over

    elif escolha_trauma == "tc":
        $ pontos -= 300
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_010.mp3"
        roberto "Paciente instável não vai para tomografia como primeira resposta. Ele precisa de ressuscitação, controle de hemorragia e decisão cirúrgica guiada pela avaliação primária e adjuntos rápidos."
        hide roberto with dissolve
        jump trauma_game_over

    $ prioridade_trauma = "D - NEUROLÓGICO"
    voice "audio/vozes/trauma/sistema/trauma_sistema_012.mp3"
    s "Após as primeiras medidas, você reavalia o neurológico considerando a via aérea já controlada. O Glasgow pré-intubação foi 8. Pupilas isocóricas e fotorreagentes."

label trauma_d_decisao:
    $ ultimo_checkpoint = "trauma_d_decisao"
    $ prioridade_trauma = "D - NEUROLÓGICO"
    $ check_trauma_d = False
    call screen menu_atls("D - DISABILITY / AVALIAÇÃO NEUROLÓGICA", [
        ("Registrar Glasgow pré-intubação, avaliar pupilas, checar glicemia capilar e prevenir hipóxia e hipotensão.", "avaliar"),
        ("Sedá-lo profundamente agora para ele parar de se mexer e facilitar a equipe.", "sedar"),
        ("Ignorar Glasgow por enquanto, porque o problema principal é ortopédico.", "ignorar")
    ])
    $ escolha_trauma = _return

    if escolha_trauma == "avaliar":
        $ check_trauma_d = True
        $ pontos += 120
        $ glasgow_trauma = 8
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_011.mp3"
        roberto "Correto. Depois da intubação, registre a avaliação neurológica possível e reavalie continuamente. No trauma cranioencefálico, hipóxia e hipotensão pioram lesão secundária."
        hide roberto with dissolve
        voice "audio/vozes/trauma/sistema/trauma_sistema_013.mp3"
        s "{color=#00e5ff}Feedback educativo:{/color} Glasgow pré-intubação, pupilas e glicemia ajudam a acompanhar evolução neurológica e evitam atribuir rebaixamento a uma causa única."

    elif escolha_trauma == "sedar":
        $ pontos -= 200
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_012.mp3"
        roberto "Sedação sem indicação clara pode mascarar exame neurológico e piorar a avaliação. Primeiro registre o estado neurológico possível e reavalie."
        hide roberto with dissolve
        jump trauma_game_over

    elif escolha_trauma == "ignorar":
        $ pontos -= 200
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_013.mp3"
        roberto "Não. ATLS não permite visão de túnel. A avaliação neurológica faz parte da avaliação primária e muda prioridade, via aérea e prognóstico."
        hide roberto with dissolve
        jump trauma_game_over

    $ prioridade_trauma = "E - EXPOSIÇÃO"
    voice "audio/vozes/trauma/sistema/trauma_sistema_014.mp3"
    s "A sala está fria. O paciente foi parcialmente exposto durante os procedimentos. Há hematoma em flanco esquerdo e abrasões em membros inferiores."

label trauma_e_decisao:
    $ ultimo_checkpoint = "trauma_e_decisao"
    $ prioridade_trauma = "E - EXPOSIÇÃO"
    $ check_trauma_e = False
    call screen menu_atls("E - EXPOSIÇÃO E CONTROLE AMBIENTAL", [
        ("Expor completamente, procurar lesões ocultas, manter proteção da coluna e aquecer ativamente o paciente.", "expor"),
        ("Manter coberto e não expor para evitar hipotermia, já que a suspeita principal é pelve.", "cobrir"),
        ("Retirar todos os dispositivos de imobilização para avaliar melhor a coluna.", "retirar")
    ])
    $ escolha_trauma = _return

    if escolha_trauma == "expor":
        $ check_trauma_e = True
        $ pontos += 120
        $ temp_trauma = 36.2
        show clara normal at slide_in_left
        voice "audio/vozes/trauma/clara/trauma_clara_005.mp3"
        clara "Exposição concluída com proteção da coluna. Sem ferida posterior exsanguinante. Aquecedor e cobertores térmicos instalados."
        hide clara with dissolve
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_014.mp3"
        roberto "Bom. Expor não é deixar esfriar. Hipotermia piora coagulopatia e sangramento."
        hide roberto with dissolve
        voice "audio/vozes/trauma/sistema/trauma_sistema_015.mp3"
        s "{color=#00e5ff}Feedback educativo:{/color} exposição completa deve vir junto de aquecimento ativo. No trauma, hipotermia agrava coagulopatia e sangramento."

    elif escolha_trauma == "cobrir":
        $ pontos -= 180
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_015.mp3"
        roberto "Você precisa procurar lesões ocultas. O correto é expor, examinar e aquecer ativamente. Não examinar também coloca o paciente em risco."
        hide roberto with dissolve
        jump trauma_game_over

    elif escolha_trauma == "retirar":
        $ pontos -= 220
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_016.mp3"
        roberto "Não sem controle e indicação. Dispositivos de imobilização só devem ser manipulados mantendo proteção da coluna e evitando movimentação desnecessária."
        hide roberto with dissolve
        jump trauma_game_over

    $ prioridade_trauma = "ADJUNTOS"
    voice "audio/vozes/trauma/sistema/trauma_sistema_016.mp3"
    s "A avaliação primária foi concluída e as ameaças imediatas foram tratadas. O paciente ainda precisa de definição rápida da fonte hemorrágica."

label trauma_adj_decisao:
    $ ultimo_checkpoint = "trauma_adj_decisao"
    $ prioridade_trauma = "ADJUNTOS"
    $ check_trauma_adj = False
    call screen menu_atls("ADJUNTOS DA AVALIAÇÃO PRIMÁRIA", [
        ("Realizar FAST à beira-leito; se positivo em paciente instável, acionar cirurgia para controle de dano e manter ressuscitação hemostática.", "fast"),
        ("Levar para TC com contraste, porque agora já fizemos todos os passos do ABCDE.", "tc"),
        ("Esperar a pressão normalizar totalmente antes de chamar cirurgia.", "esperar")
    ])
    $ escolha_trauma = _return

    if escolha_trauma == "fast":
        $ check_trauma_adj = True
        $ pontos += 220
        show clara normal at slide_in_left
        voice "audio/vozes/trauma/clara/trauma_clara_006.mp3"
        clara "FAST positivo em quadrante superior direito e pelve. Centro cirúrgico avisado. Banco de sangue mantém protocolo de transfusão."
        hide clara with dissolve
        voice "audio/vozes/trauma/sistema/trauma_sistema_017.mp3"
        s "{color=#00e5ff}Feedback educativo:{/color} FAST positivo em paciente instável direciona controle de dano. O exame ajuda a decidir rápido, não a atrasar a cirurgia."
        jump trauma_sucesso

    elif escolha_trauma == "tc":
        $ pontos -= 250
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_017.mp3"
        roberto "ABCDE feito não significa estabilidade. FAST positivo com instabilidade aponta para controle cirúrgico, não transferência para tomografia."
        hide roberto with dissolve
        jump trauma_game_over

    elif escolha_trauma == "esperar":
        $ pontos -= 220
        show roberto normal at slide_in_right
        voice "audio/vozes/trauma/roberto/trauma_roberto_018.mp3"
        roberto "Atraso perigoso. Ressuscitação e controle de hemorragia caminham juntos. Se a fonte é cirúrgica, esperar estabilidade perfeita pode ser esperar demais."
        hide roberto with dissolve
        jump trauma_game_over

label trauma_sucesso:
    $ prioridade_trauma = "CONTROLE DE DANO"
    $ pa_trauma = "106/68"
    $ pa_sistolica_trauma = 106
    $ fc_trauma = 104
    $ sato2_trauma = 96
    $ temp_trauma = 36.4

    show roberto normal at slide_in_right
    voice "audio/vozes/trauma/roberto/trauma_roberto_019.mp3"
    roberto "Muito bem. Você respeitou a sequência ATLS: tratou ameaças imediatas antes dos exames definitivos. Esse raciocínio salva no trauma."
    hide roberto with dissolve

    hide screen trauma_hud
    hide screen botao_checklist_trauma
    scene black with fade

    $ salvar_no_banco(nome_jogador, matricula_jogador, pontos, "Politrauma_ATLS", "Sucesso")

    call screen debriefing_simples(
        "CASO ATLS CONCLUÍDO",
        "Sucesso",
        "Paciente estabilizado e encaminhado para controle definitivo de danos",
        pontos,
        "ATLS - Avaliação Primária ABCDE",
        [
            "Você reconheceu Glasgow 8 com hipoxemia e controlou via aérea mantendo proteção cervical.",
            "Tratou pneumotórax hipertensivo como diagnóstico clínico, sem aguardar radiografia.",
            "Controlou suspeita de hemorragia pélvica, preveniu hipotermia e usou FAST para direcionar controle de dano."
        ],
        "Debriefing: o desempenho foi bom porque você manteve a prioridade do paciente instável. No trauma, tomografia e exames definitivos só entram depois que A, B e C estão protegidos ou quando o paciente permite."
    )
    jump escolha_caso

label trauma_game_over:
    $ pa_trauma = "60/30"
    $ pa_sistolica_trauma = 60
    $ sato2_trauma = 78
    $ fc_trauma = 148
    with hpunch

    show clara tensa at slide_in_left
    voice "audio/vozes/trauma/clara/trauma_clara_007.mp3"
    clara "Doutor(a), ele está deteriorando. Pressão despencando, saturação baixa e piora neurológica progressiva."
    hide clara with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/trauma/roberto/trauma_roberto_020.mp3"
    roberto "No trauma, pular o ABCDE ou atrasar o controle de ameaça imediata custa tempo, sangue e cérebro. Refaça a etapa com prioridade."
    hide roberto with dissolve

    hide screen trauma_hud
    hide screen botao_checklist_trauma
    scene black with fade

    $ salvar_no_banco(nome_jogador, matricula_jogador, pontos, "Politrauma_ATLS", "Falha")

    call screen debriefing_simples(
        "DEBRIEFING DO POLITRAUMA",
        "Falha",
        "Paciente não estabilizado; permanece em deterioração crítica",
        pontos,
        "ATLS - Avaliação Primária ABCDE",
        [
            "Identifique em qual letra do ABCDE a ameaça imediata foi ignorada ou atrasada.",
            "Se houver instabilidade, pneumotórax hipertensivo e hemorragia provável são tratados antes de imagem definitiva.",
            "Reavaliação contínua é parte do ATLS: melhorar um item não autoriza esquecer os anteriores."
        ],
        "Debriefing: a falha sugere quebra de prioridade. No politrauma instável, a pergunta central é sempre: qual ameaça mata primeiro e pode ser tratada agora?"
    )

    call screen menu_pos_falha(
        "FALHA CRÍTICA",
        "O politrauma deteriorou durante a avaliação primária. Escolha como deseja prosseguir no treinamento."
    )
    $ escolha_pos_falha = _return

    if escolha_pos_falha == "retry":
        scene bg trauma
        show screen trauma_hud
        show screen botao_checklist_trauma
        $ renpy.jump(ultimo_checkpoint)
    elif escolha_pos_falha == "casos":
        jump escolha_caso
    else:
        $ renpy.quit()


# ==============================================================================
#                       CASO 2: O BATISMO DE FOGO (AHA/ACC 2025)
# ==============================================================================
label caso_batismo:
    # Variáveis do Caso 2
    $ vida_coracao = 100
    $ ritmo = "sinusal"
    $ fc_acls = 115
    $ pas_acls = 148
    $ pad_acls = 92
    $ pontos = 1000 # Sistema de Pontuação Dinâmica do Aluno (começa com 1000)
    $ check_ecg = check_pulso = check_choque = check_drogas_pcr = check_vasoativo = False
    $ ecg_precoce = False # Variável para rastrear se o ECG foi feito no tempo correto

    scene bg sala_vermelha
    show screen acls_hud
    show screen botao_checklist_acls

    # Cena 1: A chegada à Sala Vermelha
    voice "audio/vozes/acls/sistema/acls_sistema_001.mp3"
    s "A Sala Vermelha está pronta para o turno. Monitor, desfibrilador e carrinho de emergência foram checados antes da chegada do próximo paciente."
    voice "audio/vozes/acls/sistema/acls_sistema_002.mp3"
    s "O rádio informa: homem de 58 anos com dor torácica opressiva iniciada há quarenta minutos, sudorese e náusea. A ambulância está entrando no setor."

    show roberto normal at slide_in_right
    voice "audio/vozes/acls/roberto/acls_roberto_001.mp3"
    roberto "Doutor(a), assuma este atendimento. Na suspeita de síndrome coronariana aguda, precisamos reconhecer isquemia rapidamente e preparar reperfusão sem atrasos evitáveis."
    hide roberto with dissolve

    show clara normal at slide_in_left
    voice "audio/vozes/acls/clara/acls_clara_001.mp3"
    clara "Box 1. Sr. Osvaldo, 58 anos. Dor retroesternal opressiva, irradiada para o braço esquerdo, com sudorese e náusea. Pressão 148 por 92, frequência 115."
    hide clara with dissolve

    show marcos normal at slide_in_left
    voice "audio/vozes/acls/marcos/acls_marcos_001.mp3"
    marcos "Monitorização iniciada e acesso venoso em preparo. O desfibrilador bifásico deste box está disponível se houver deterioração."
    hide marcos with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/acls/roberto/acls_roberto_002.mp3"
    roberto "Conduza os primeiros minutos. Priorize as medidas que mudam desfecho."
    hide roberto with dissolve

    # Cena 2: A Avaliação Inicial (Protocolo de SCA - Síndrome Coronariana Aguda)
    voice "audio/vozes/acls/sistema/acls_sistema_003.mp3"
    s "Você se aproxima do leito. O Sr. Osvaldo está pálido, diaforético e mantém a mão sobre o centro do peito."

    # Inicia o som do monitor apenas quando você chega no leito do paciente

    voice "audio/vozes/acls/osvaldo/acls_osvaldo_001.mp3"
    osvaldo "(Ofegante) Doutor... é uma pressão muito forte no peito... está indo para o braço esquerdo. Começou há uns quarenta minutos."

    show roberto normal at slide_in_right
    voice "audio/vozes/acls/roberto/acls_roberto_003.mp3"
    roberto "A apresentação é compatível com síndrome coronariana aguda até prova em contrário. Qual é sua primeira ordem?"
    hide roberto with dissolve

label acls_sca_decisao:
    $ ultimo_checkpoint = "acls_sca_decisao"
    # --- RESET DE VITAIS DO CHECKPOINT ---
    $ vida_coracao = 100
    $ ritmo = "sinusal"
    $ fc_acls = 115
    $ pas_acls = 148
    $ pad_acls = 92
    $ check_ecg = False
    $ ecg_precoce = False
    # --------------------------------------
    menu:
        "DECISÃO IMEDIATA (SCA - AHA/ACC 2025):"
        "Realizar ECG de 12 derivações em até 10 minutos e administrar AAS 300mg mastigado, se não houver contraindicação.":
            $ check_ecg = True
            $ ecg_precoce = True
            $ pontos += 100
            show clara normal at slide_in_left
            voice "audio/vozes/acls/clara/acls_clara_002.mp3"
            clara "Sem contraindicação informada. AAS 300 miligramas mastigado administrado. ECG de doze derivações sendo realizado agora."
            hide clara with dissolve

            # --- MOSTRA A PRIMEIRA FOTO DO ECG LIMPA PRIMEIRO (SEM DIÁLOGO) ---
            window hide
            show ecg_infarto at truecenter with dissolve
            pause # Espera o clique do usuário apreciando a imagem em tela limpa

            # --- AGORA EXIBE O TEXTO COM O ECG DE FUNDO ---
            window show
            voice "audio/vozes/acls/sistema/acls_sistema_004.mp3"
            s "O ECG é obtido dentro dos primeiros dez minutos. Analise o traçado e determine a próxima prioridade."

            menu:
                "INTERPRETAÇÃO DO ECG:"
                "Supradesnivelamento do segmento ST compatível com IAM com supra (IAMST).":
                    $ pontos += 75
                    show roberto normal at slide_in_right
                    voice "audio/vozes/acls/roberto/acls_roberto_004.mp3"
                    roberto "Correto. Há supradesnivelamento persistente do segmento ST, compatível com infarto com supra. Ative imediatamente a estratégia de reperfusão."
                    hide roberto with dissolve

                "Ritmo sinusal normal, sem sinais de isquemia aguda.":
                    $ pontos -= 75
                    show roberto normal at slide_in_right
                    voice "audio/vozes/acls/roberto/acls_roberto_005.mp3"
                    roberto "Reavalie o traçado. O supradesnivelamento do segmento ST é o achado crítico; classificá-lo como normal atrasaria a reperfusão."
                    hide roberto with dissolve

                "Fibrilação ventricular, ritmo chocável de parada cardíaca.":
                    $ pontos -= 50
                    show roberto normal at slide_in_right
                    voice "audio/vozes/acls/roberto/acls_roberto_006.mp3"
                    roberto "Ainda não. Este traçado demonstra isquemia transmural aguda. A fibrilação ventricular será reconhecida por atividade elétrica desorganizada no monitor."
                    hide roberto with dissolve

            hide ecg_infarto with dissolve
            # -------------------------------------

            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_007.mp3"
            roberto "Boa conduta. ECG precoce, AAS quando indicado e acionamento rápido da reperfusão reduzem atrasos no cuidado do infarto com supra."
            hide roberto with dissolve
            show clara normal at slide_in_left
            voice "audio/vozes/acls/clara/acls_clara_003.mp3"
            clara "Infarto com supra comunicado. Hemodinâmica acionada para intervenção coronariana percutânea primária; transferência em preparação."
            hide clara with dissolve
            voice "audio/vozes/acls/sistema/acls_sistema_005.mp3"
            s "{color=#00e5ff}Feedback educativo:{/color} na suspeita de síndrome coronariana aguda, o ECG deve ser obtido rapidamente; no infarto com supra, a reperfusão é prioridade."

        "Sr. Osvaldo, o senhor tem histórico familiar de doenças cardíacas? Alguém na família já infartou?":
            $ vida_coracao -= 20
            $ pontos -= 200
            voice "audio/vozes/acls/osvaldo/acls_osvaldo_002.mp3"
            osvaldo "(Gemendo) Meu pai teve infarto... mas, doutor, essa dor está piorando..."
            with hpunch

            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_008.mp3"
            roberto "A história dirigida é importante, mas não deve atrasar o ECG. Clara, faça as doze derivações agora e confirme contraindicações para o AAS."
            hide roberto with dissolve
            $ check_ecg = True

        "Ele está com muita dor. Clara, faça 4mg de Morfina na veia agora para aliviar o sofrimento.":
            $ vida_coracao -= 40
            $ pontos -= 300
            $ fc_acls = 140

            show clara tensa at slide_in_left
            voice "audio/vozes/acls/clara/acls_clara_004.mp3"
            clara "Antes da analgesia, ainda não registramos o ECG nem avaliamos AAS. A morfina não substitui o diagnóstico e pode interferir na absorção de antiplaquetários orais."
            hide clara with dissolve

            if voz_jogador == "feminina":
                voice "audio/vozes/acls/jogador/acls_jogador_feminino_001.mp3"
            else:
                voice "audio/vozes/acls/jogador/acls_jogador_masculino_001.mp3"
            p "Administre a analgesia e providencie o ECG imediatamente."
            with hpunch

            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_009.mp3"
            roberto "Você priorizou alívio sintomático antes das medidas tempo-dependentes. Em suspeita de infarto, ECG, terapia antitrombótica indicada e reperfusão não podem ser atrasados."
            hide roberto with dissolve
            $ check_ecg = True

    if vida_coracao <= 0:
        jump acls_game_over

    # Scene 3: A Virada (A Parada Cardíaca)
    if ecg_precoce:
        voice "audio/vozes/acls/sistema/acls_sistema_006.mp3"
        s "Mesmo com o reconhecimento rápido e a hemodinâmica acionada, o infarto pode complicar com arritmia ventricular antes da reperfusão. Osvaldo leva a mão ao peito e o monitor muda abruptamente."
    else:
        voice "audio/vozes/acls/sistema/acls_sistema_007.mp3"
        s "Enquanto a equipe tenta recuperar o atraso no diagnóstico inicial, Osvaldo empalidece ainda mais. Antes da reperfusão, o monitor muda abruptamente."

    with hpunch
    $ ritmo = "fv"
    $ fc_acls = 220

    # --- MOSTRA A SEGUNDA FOTO: O MONITOR EM FIBRILAÇÃO LIMPO PRIMEIRO ---
    window hide
    show monitor_fv at truecenter with dissolve
    pause # Espera o clique do usuário olhando o monitor de forma independente

    # --- AGORA EXIBE O TEXTO COM O MONITOR DE FUNDO ---
    window show
    voice "audio/vozes/acls/sistema/acls_sistema_008.mp3"
    s "O monitor exibe um novo ritmo. Identifique-o rapidamente para orientar a próxima intervenção."

    menu:
        "INTERPRETAÇÃO DO MONITOR:"
        "Fibrilação ventricular: ritmo chocável, sem pulso efetivo.":
            $ pontos += 75
            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_010.mp3"
            roberto "Exato. Fibrilação ventricular é ritmo chocável. Se o paciente estiver sem pulso, a prioridade é desfibrilar com pausa mínima e retomar a RCP imediatamente."
            hide roberto with dissolve

        "Assistolia: linha reta, ritmo não chocável.":
            $ pontos -= 75
            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_011.mp3"
            roberto "Não é assistolia. O traçado mostra atividade caótica, compatível com fibrilação ventricular, um ritmo chocável."
            hide roberto with dissolve

        "Taquicardia sinusal com pulso preservado.":
            $ pontos -= 75
            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_012.mp3"
            roberto "Não. Diante de perda de responsividade e ritmo desorganizado, verifique pulso imediatamente e prepare abordagem de parada em ritmo chocável."
            hide roberto with dissolve

    hide monitor_fv with dissolve
    # ------------------------------------------------------

    if ecg_precoce:
        voice "audio/vozes/acls/sistema/acls_sistema_009.mp3"
        s "O Sr. Osvaldo perde subitamente a consciência e deixa de responder."
    else:
        voice "audio/vozes/acls/sistema/acls_sistema_010.mp3"
        s "Antes que a avaliação inicial seja completada, o Sr. Osvaldo perde a consciência e deixa de responder."

    show clara tensa at slide_in_left
    voice "audio/vozes/acls/clara/acls_clara_005.mp3"
    clara "Doutor(a), ele não responde e não respira normalmente!"
    hide clara with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/acls/roberto/acls_roberto_013.mp3"
    roberto "Verifique pulso por no máximo dez segundos. Se não houver pulso definido, inicie compressões e solicite o desfibrilador."
    hide roberto with dissolve

label acls_pcr_decisao:
    $ ultimo_checkpoint = "acls_pcr_decisao"
    # --- RESET DE VITAIS DO CHECKPOINT ---
    $ ritmo = "fv"
    $ fc_acls = 220
    $ check_pulso = False
    if vida_coracao < 60:
        $ vida_coracao = 80
    # --------------------------------------
    menu:
        "PROTOCOLO DE PARADA (AHA ACLS 2025):"
        "Solicitar o carrinho de emergência e checar pulso carotídeo e respiração simultaneamente por no máximo 10 segundos.":
            $ check_pulso = True
            $ pontos += 100
            voice "audio/vozes/acls/sistema/acls_sistema_011.mp3"
            s "Você verifica pulso carotídeo enquanto observa a respiração. Após cinco segundos, não identifica pulso nem respiração normal."
            if voz_jogador == "feminina":
                voice "audio/vozes/acls/jogador/acls_jogador_feminino_002.mp3"
            else:
                voice "audio/vozes/acls/jogador/acls_jogador_masculino_002.mp3"
            p "Parada cardiorrespiratória confirmada. Clara, acione o Código Azul. Marcos, inicie compressões e traga o desfibrilador."
            voice "audio/vozes/acls/sistema/acls_sistema_012.mp3"
            s "{color=#00e5ff}Feedback educativo:{/color} em adulto inconsciente sem respiração normal, a verificação de pulso não deve exceder dez segundos antes do início da RCP."

        "Gritar por ajuda, correr para buscar o desfibrilador no corredor e afastar todos.":
            $ vida_coracao -= 30
            $ pontos -= 200
            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_014.mp3"
            roberto "Não abandone o paciente. Acione ajuda, verifique rapidamente pulso e respiração e inicie RCP; outro membro da equipe busca o desfibrilador."
            hide roberto with dissolve

            voice "audio/vozes/acls/roberto/acls_roberto_015.mp3"
            roberto "Sem pulso definido. Inicie compressões agora; o desfibrilador está a caminho."
            $ check_pulso = True

        "Iniciar ventilação com a máscara (Ambu) imediatamente, priorizando a oxigenação.":
            $ vida_coracao -= 30
            $ pontos -= 200
            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_016.mp3"
            roberto "Na parada de adulto, após confirmar ausência de pulso, as compressões têm prioridade. Ventilação isolada atrasaria o início da RCP."
            hide roberto with dissolve

            voice "audio/vozes/acls/roberto/acls_roberto_017.mp3"
            roberto "Sem pulso definido. Comece compressões de alta qualidade imediatamente."
            $ check_pulso = True

    if vida_coracao <= 0:
        jump acls_game_over

    # Cena 4: O Choque (O Clímax) - MENU CRONOMETRADO (1º CHOQUE)
    $ fc_acls = 0
    voice "audio/vozes/acls/sistema/acls_sistema_013.mp3"
    s "A equipe inicia compressões torácicas enquanto os adesivos do desfibrilador são aplicados."

    show marcos normal at slide_in_left
    voice "audio/vozes/acls/marcos/acls_marcos_002.mp3"
    marcos "Compressões em 110 por minuto, profundidade entre 5 e 6 centímetros e retorno completo do tórax. Adesivos aplicados; desfibrilador bifásico pronto."
    hide marcos with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/acls/roberto/acls_roberto_018.mp3"
    roberto "Pausa mínima para análise do ritmo. Retome as compressões assim que a conduta for definida."
    hide roberto with dissolve

    voice "audio/vozes/acls/sistema/acls_sistema_014.mp3"
    s "Durante a pausa breve, o monitor confirma fibrilação ventricular."
    stop monitor fadeout 0.3

    show roberto normal at slide_in_right
    voice "audio/vozes/acls/roberto/acls_roberto_019.mp3"
    roberto "Fibrilação ventricular sem pulso. O desfibrilador bifásico deste box está configurado para choque inicial de 200 joules. Qual é a conduta imediata?"
    hide roberto with dissolve

    window hide

label acls_choque_decisao:
    $ ultimo_checkpoint = "acls_choque_decisao"
    # --- RESET DE VITAIS DO CHECKPOINT ---
    $ ritmo = "fv"
    $ fc_acls = 0
    $ check_choque = False
    $ check_rcp = False
    if vida_coracao < 60:
        $ vida_coracao = 80
    stop monitor fadeout 0.3
    # --------------------------------------
    # Chama o menu que tem 10 segundos para responder
    call screen menu_cronometrado_acls
    $ escolha_final = _return

    if escolha_final == "choque":
        $ check_choque = True
        $ pontos += 100

        show clara tensa at slide_in_left
        # --- TOCA O ÁUDIO DO DESFIBRILADOR CARREGANDO COM PAUSA DE 2 SEGUNDOS ---
        play sound "audio/desfibila.mp3"
        voice "audio/vozes/acls/clara/acls_clara_006.mp3"
        clara "Carregando 200 joules. {w=2.0}Todos afastados. Choque administrado. Retomem as compressões imediatamente."
        hide clara with dissolve

        scene bg sala_vermelha with flash
        stop monitor

        # --- NOVO MINIJOGO DE RITMO DE RCP CARDÍACA (FACILITADO) ---
        voice "audio/vozes/acls/sistema/acls_sistema_015.mp3"
        s "Você assume as compressões. Mantenha frequência entre 100 e 120 por minuto, posição correta das mãos e retorno completo do tórax."
        call screen minigame_rcp
        if _return == "win":
            $ pontos += 150
            voice "audio/vozes/acls/sistema/acls_sistema_016.mp3"
            s "Compressões adequadas. A RCP é mantida durante o ciclo após a desfibrilação."
            voice "audio/vozes/acls/sistema/acls_sistema_017.mp3"
            s "{color=#00e5ff}Feedback educativo:{/color} em FV sem pulso, a pausa para choque deve ser mínima e a RCP precisa ser retomada imediatamente."
            jump acls_ciclo_2
        else:
            $ pontos -= 200
            voice "audio/vozes/acls/sistema/acls_sistema_018.mp3"
            s "As compressões não atingiram frequência e técnica adequadas durante o ciclo. A chance de retorno da circulação diminui."
            jump acls_game_over

    elif escolha_final == "adrenalina":
        voice "audio/vozes/acls/sistema/acls_sistema_019.mp3"
        s "Você priorizou adrenalina antes da primeira desfibrilação. Em FV ou TV sem pulso, a sequência inicial exige choque precoce e RCP; a adrenalina é administrada após o segundo choque."
        jump acls_game_over

    elif escolha_final == "intubar":
        voice "audio/vozes/acls/sistema/acls_sistema_020.mp3"
        s "Você priorizou a via aérea avançada enquanto persistia um ritmo chocável. A desfibrilação foi atrasada e o paciente permaneceu sem perfusão efetiva."
        jump acls_game_over

    elif escolha_final == "timeout":
        voice "audio/vozes/acls/sistema/acls_sistema_021.mp3"
        s "A desfibrilação não foi realizada dentro do tempo crítico. A fibrilação ventricular persiste sem débito efetivo."
        jump acls_game_over

# ==============================================================================
#                       NOVO MÓDULO: CICLOS DE RCP E DROGAS VASOATIVAS
# ==============================================================================

label acls_ciclo_2:
    voice "audio/vozes/acls/sistema/acls_sistema_022.mp3"
    s "Após o primeiro choque, a RCP prossegue por dois minutos. Clara ventila com bolsa-válvula-máscara, evitando interrupções prolongadas nas compressões."
    voice "audio/vozes/acls/sistema/acls_sistema_023.mp3"
    s "Ao fim do ciclo, a equipe realiza uma pausa mínima para nova análise do ritmo."

    show roberto normal at slide_in_right
    # --- SEGUNDO CHOQUE: TOCA O ÁUDIO DO DESFIBRILADOR CARREGANDO ---
    play sound "audio/desfibila.mp3"
    voice "audio/vozes/acls/roberto/acls_roberto_020.mp3"
    roberto "Análise: fibrilação ventricular persiste. Carregando 200 joules. {w=2.0}Todos afastados. Segundo choque administrado. Retomem RCP."
    hide roberto with dissolve

    scene bg sala_vermelha with flash
    voice "audio/vozes/acls/sistema/acls_sistema_024.mp3"
    s "As compressões são retomadas imediatamente. Durante a RCP, Clara confirma acesso venoso periférico funcionante."

    show clara normal at slide_in_left
    voice "audio/vozes/acls/clara/acls_clara_007.mp3"
    clara "Acesso venoso calibre 18 funcionante. Estamos no ciclo após o segundo choque. Qual medicação devo administrar durante a RCP?"
    hide clara with dissolve

label acls_ciclo_2_decisao:
    $ ultimo_checkpoint = "acls_ciclo_2_decisao"
    # --- RESET DE VITAIS DO CHECKPOINT ---
    $ ritmo = "fv"
    $ fc_acls = 0
    $ check_drogas_pcr = False
    if vida_coracao < 60:
        $ vida_coracao = 80
    stop monitor fadeout 0.3
    # --------------------------------------
    menu:
        "FARMACOTERAPIA NA PCR (2º CICLO):"
        "Administrar Adrenalina 1mg IV em bolus agora, seguida de flush de 20ml de soro e elevação do membro.":
            $ check_drogas_pcr = True
            $ pontos += 150
            show clara normal at slide_in_left
            voice "audio/vozes/acls/clara/acls_clara_008.mp3"
            clara "Adrenalina 1 miligrama intravenosa administrada, seguida de flush. Cronometrando o intervalo para eventual nova dose."
            hide clara with dissolve

            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_021.mp3"
            roberto "Correto. Em fibrilação ventricular persistente, administre adrenalina após o segundo choque e repita a cada três a cinco minutos enquanto a ressuscitação prosseguir."
            hide roberto with dissolve
            voice "audio/vozes/acls/sistema/acls_sistema_025.mp3"
            s "{color=#00e5ff}Feedback educativo:{/color} em ritmo chocável, choque e RCP vêm primeiro; a adrenalina entra após o segundo choque, sem interromper as compressões."

        "Administrar Amiodarona 300mg IV em bolus agora.":
            $ pontos -= 150
            $ vida_coracao = 0
            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_022.mp3"
            roberto "Sequência incorreta. Após o segundo choque, a medicação indicada neste ciclo é adrenalina. Amiodarona ou lidocaína serão considerados se a FV persistir após novo choque."
            hide roberto with dissolve
            voice "audio/vozes/acls/sistema/acls_sistema_026.mp3"
            s "A medicação prevista para este ciclo não foi administrada e a fibrilação ventricular permanece sem reversão."
            jump acls_game_over

        "Iniciar infusão contínua de Noradrenalina na bomba de infusão.":
            $ pontos -= 250
            $ vida_coracao = 0
            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_023.mp3"
            roberto "Ainda não houve retorno da circulação. Infusão contínua de noradrenalina pertence ao suporte após RCE; durante esta PCR, siga choque, RCP e adrenalina."
            hide roberto with dissolve
            voice "audio/vozes/acls/sistema/acls_sistema_027.mp3"
            s "A sequência do algoritmo foi atrasada e o paciente permanece sem perfusão efetiva."
            jump acls_game_over

    if vida_coracao <= 0:
        jump acls_game_over

    jump acls_ciclo_3

label acls_ciclo_3:
    voice "audio/vozes/acls/sistema/acls_sistema_028.mp3"
    s "O ciclo de RCP após adrenalina é concluído, mantendo compressões de alta qualidade. A equipe faz nova pausa mínima para análise do ritmo."

    show roberto normal at slide_in_right
    # --- TERCEIRO CHOQUE: TOCA O ÁUDIO DO DESFIBRILADOR CARREGANDO ---
    play sound "audio/desfibila.mp3"
    voice "audio/vozes/acls/roberto/acls_roberto_024.mp3"
    roberto "Fibrilação ventricular persiste. Carregando 200 joules. {w=2.0}Todos afastados. Terceiro choque administrado. Retomem compressões."
    hide roberto with dissolve

    scene bg sala_vermelha with flash

    show clara normal at slide_in_left
    voice "audio/vozes/acls/clara/acls_clara_009.mp3"
    clara "RCP retomada. O paciente recebeu adrenalina e permanece em fibrilação ventricular após o terceiro choque. Qual antiarrítmico preparo agora?"
    hide clara with dissolve

label acls_ciclo_3_decisao:
    $ ultimo_checkpoint = "acls_ciclo_3_decisao"
    # --- RESET DE VITAIS DO CHECKPOINT ---
    $ ritmo = "fv"
    $ fc_acls = 0
    if vida_coracao < 60:
        $ vida_coracao = 80
    stop monitor fadeout 0.3
    # --------------------------------------
    menu:
        "FARMACOTERAPIA NA PCR (3º CICLO):"
        "Administrar Amiodarona 300mg IV em bolus agora.":
            $ check_drogas_pcr = True
            $ pontos += 150
            show clara normal at slide_in_left
            voice "audio/vozes/acls/clara/acls_clara_010.mp3"
            clara "Amiodarona 300 miligramas intravenosa administrada durante a RCP."
            hide clara with dissolve

            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_025.mp3"
            roberto "Correto. Amiodarona 300 miligramas é uma opção indicada para fibrilação ventricular ou taquicardia ventricular sem pulso refratária aos choques."
            hide roberto with dissolve
            voice "audio/vozes/acls/sistema/acls_sistema_029.mp3"
            s "{color=#00e5ff}Feedback educativo:{/color} amiodarona ou lidocaína podem ser usadas na FV ou TV sem pulso refratária durante a continuidade da RCP."

        "Administrar mais 1mg de Adrenalina IV agora.":
            $ pontos -= 150
            $ vida_coracao = 0
            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_026.mp3"
            roberto "Respeite o intervalo de três a cinco minutos para a adrenalina. Neste ciclo, após o terceiro choque com FV persistente, administre amiodarona ou lidocaína durante a RCP."
            hide roberto with dissolve
            voice "audio/vozes/acls/sistema/acls_sistema_030.mp3"
            s "O antiarrítmico indicado para a fibrilação ventricular refratária não foi administrado, e o ritmo permanece sem débito."
            jump acls_game_over

        "Administrar Gluconato de Cálcio 10%% IV rápido.":
            $ pontos -= 200
            $ vida_coracao = 0
            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_027.mp3"
            roberto "Cálcio não é medicação de rotina na parada cardíaca. Reserve-o para indicações específicas, como hipercalemia ou intoxicação compatível."
            hide roberto with dissolve
            voice "audio/vozes/acls/sistema/acls_sistema_031.mp3"
            s "A fibrilação ventricular continua refratária enquanto a terapia indicada para este ciclo não é administrada."
            jump acls_game_over

    if vida_coracao <= 0:
        jump acls_game_over

    jump acls_retorno

label acls_retorno:
    voice "audio/vozes/acls/sistema/acls_sistema_032.mp3"
    s "Após o ciclo de RCP com amiodarona, a equipe realiza nova análise com interrupção mínima das compressões."

    $ ritmo = "sinusal"
    $ fc_acls = 110
    $ pas_acls = 70
    $ pad_acls = 40

    show marcos normal at slide_in_left
    voice "audio/vozes/acls/marcos/acls_marcos_003.mp3"
    marcos "Ritmo organizado no monitor. Pausa breve para checar pulso... Pulso carotídeo presente."
    hide marcos with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/acls/roberto/acls_roberto_028.mp3"
    roberto "Retorno da circulação espontânea confirmado. Inicie cuidados pós-parada: monitore oxigenação, ventilação, pressão arterial e obtenha ECG de doze derivações."
    hide roberto with dissolve

    show clara tensa at slide_in_left
    voice "audio/vozes/acls/clara/acls_clara_011.mp3"
    clara "Pressão arterial 70 por 40 milímetros de mercúrio. Ele permanece hipotenso após o retorno da circulação."
    hide clara with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/acls/roberto/acls_roberto_029.mp3"
    roberto "Precisamos corrigir a hipotensão e manter pressão arterial média de pelo menos 65 milímetros de mercúrio. Qual suporte vasoativo você indica neste cenário?"
    hide roberto with dissolve

label acls_rce_decisao:
    $ ultimo_checkpoint = "acls_rce_decisao"
    # --- RESET DE VITAIS DO CHECKPOINT ---
    $ ritmo = "sinusal"
    $ fc_acls = 110
    $ pas_acls = 70
    $ pad_acls = 40
    $ check_vasoativo = False
    if vida_coracao < 60:
        $ vida_coracao = 80
    # --------------------------------------
    menu:
        "CUIDADOS PÓS-RCE / SUPORTE VASOATIVO:"
        "Iniciar infusão contínua de Noradrenalina a 0,1 mcg/kg/min em bomba de infusão, titulando para manter PAM >= 65 mmHg.":
            $ check_vasoativo = True
            $ pontos += 300
            $ pas_acls = 102
            $ pad_acls = 66
            show clara normal at slide_in_left
            voice "audio/vozes/acls/clara/acls_clara_012.mp3"
            clara "Noradrenalina iniciada em bomba, titulada conforme resposta. Pressão agora 102 por 66; pressão arterial média acima de 65."
            hide clara with dissolve

            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_030.mp3"
            roberto "Boa conduta. No pós-RCE com hipotensão, a infusão vasoativa titulada é apropriada para sustentar perfusão. Como ele apresentou infarto com supra, mantenha avaliação coronariana urgente."
            hide roberto with dissolve
            voice "audio/vozes/acls/sistema/acls_sistema_033.mp3"
            s "{color=#00e5ff}Feedback educativo:{/color} após RCE, trate hipotensão para manter pressão arterial média adequada e continue a estratégia de reperfusão coronariana quando indicada."

            stop monitor fadeout 2.0
            hide screen acls_hud
            hide screen botao_checklist_acls
            scene black with fade

            # Envia o score de vitória para o seu Firebase
            $ salvar_no_banco(nome_jogador, matricula_jogador, pontos, "ACLS_PCR", "Sucesso")

            call screen debriefing_simples(
                "CASO ACLS CONCLUÍDO",
                "Sucesso",
                "Sr. Osvaldo salvo, com circulação restabelecida e pressão estabilizada",
                pontos,
                "AHA/ACC 2025 - SCA e ACLS",
                [
                    "Você pediu ECG/AAS cedo diante de dor torácica típica, reduzindo atraso na SCA.",
                    "Quando o paciente evoluiu para FV sem pulso, priorizou desfibrilação e retorno imediato à RCP.",
                    "Sequenciou adrenalina, amiodarona e suporte vasoativo pós-RCE no momento clínico adequado."
                ],
                "Debriefing: o ponto forte foi tempo. Em FV, cada pausa custa perfusão; por isso o caso valoriza choque precoce, compressões entre análises e medicações sem interromper a RCP."
            )
            jump escolha_caso

        "Administrar um novo bolus rápido de 1mg de Adrenalina IV para subir a pressão imediatamente.":
            $ pontos -= 400
            $ vida_coracao = 0
            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_031.mp3"
            roberto "Neste cenário pós-RCE com pulso e infarto com supra, prefira suporte titulado por infusão. Um bolus rápido de adrenalina pode provocar taquiarritmia e aumentar consumo de oxigênio pelo miocárdio."
            hide roberto with dissolve
            jump acls_game_over

        "Administrar uma carga rápida de 1000ml de Soro Fisiológico 0.9%% gelado para expansão volêmica.":
            $ pontos -= 300
            $ vida_coracao = 0
            show roberto normal at slide_in_right
            voice "audio/vozes/acls/roberto/acls_roberto_032.mp3"
            roberto "Uma expansão pode ser considerada conforme avaliação hemodinâmica, mas administrar grande volume gelado como única resposta não é adequado neste paciente sem evidência de hipovolemia e com lesão miocárdica aguda."
            hide roberto with dissolve
            show clara tensa at slide_in_left
            voice "audio/vozes/acls/clara/acls_clara_013.mp3"
            clara "A pressão continua baixa e a oxigenação piorou. O suporte pós-parada foi atrasado e o paciente voltou a deteriorar."
            hide clara with dissolve
            jump acls_game_over

# ==============================================================================
#                       TELA DE FALHA (ACLS GAME OVER)
# ==============================================================================

label acls_game_over:
    $ ritmo = "assistolia"
    stop monitor
    play sound "audio/linha_reta.mp3"
    with hpunch

    show clara tensa at slide_in_left
    voice "audio/vozes/acls/clara/acls_clara_014.mp3"
    clara "Doutor(a), o monitor agora mostra assistolia. Não identifico pulso."
    hide clara with dissolve

    show roberto normal at slide_in_right
    voice "audio/vozes/acls/roberto/acls_roberto_033.mp3"
    roberto "A ressuscitação não obteve retorno da circulação. Precisamos revisar se houve atraso no choque, falha na qualidade da RCP ou quebra na sequência das medicações."
    hide roberto with dissolve

    voice "audio/vozes/acls/sistema/acls_sistema_034.mp3"
    s "Após a reanimação sem retorno da circulação espontânea, o óbito do Sr. Osvaldo é declarado."

    show roberto normal at slide_in_right
    voice "audio/vozes/acls/roberto/acls_roberto_034.mp3"
    roberto "Registre o desfecho. Em seguida, faremos o debriefing da equipe para identificar oportunidades de melhoria."
    hide roberto with dissolve

    hide screen acls_hud
    hide screen botao_checklist_acls
    scene black with fade

    # Envia o score de falha para o seu Firebase
    $ salvar_no_banco(nome_jogador, matricula_jogador, pontos, "ACLS_PCR", "Falha")

    call screen debriefing_simples(
        "DEBRIEFING DO ACLS",
        "Falha",
        "Óbito do Sr. Osvaldo declarado após reanimação sem sucesso",
        pontos,
        "AHA/ACC 2025 - SCA e ACLS",
        [
            "Revise se o ritmo era chocável antes de escolher medicação ou via aérea.",
            "Em FV/TV sem pulso, desfibrilação precoce e RCP imediata valem mais que qualquer intervenção demorada.",
            "Adrenalina, amiodarona e noradrenalina pertencem a fases diferentes: PCR refratária e pós-RCE não são a mesma situação."
        ],
        "Debriefing: a perda do paciente indica inversão de prioridade ou pausa excessiva. O ACLS pune atraso porque perfusão coronariana e cerebral caem a cada interrupção."
    )

    call screen menu_pos_falha(
        "FALHA CRÍTICA",
        "O paciente evoluiu para óbito durante o atendimento ACLS. Escolha como deseja prosseguir no treinamento."
    )
    $ escolha_pos_falha = _return

    if escolha_pos_falha == "retry":
        $ renpy.jump(ultimo_checkpoint)
    elif escolha_pos_falha == "casos":
        jump escolha_caso
    else:
        $ renpy.quit()
